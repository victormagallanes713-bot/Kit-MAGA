"""
Modulo 22 - Huella digital contractual + reparto economico.  v2

Modelo (parametros configurables, en puntos base: 10000 = 100 %):
  - Huella digital unica por produccion que enlaza al contrato de reparto.
  - Reparto 55 % titular / 45 % empresa.
  - Comision tecnologica 15 % sobre lo que recibe el titular.
  - Adquisicion parcial (modos descritos en calcular_adquisicion).
  - Licencia de voz (NO cesion) asociada a la produccion.

Cambios respecto a v1:
  - Todo el dinero va en CENTAVOS enteros; el reparto suma exactamente el pago.
  - Un pago solo se registra si existe un evento de cobro CONFIRMADO en el
    modulo 7 (estado PROCESSED). El monto sale de ese evento, no de quien llama.
  - c2pa y disclosure_ia se guardan como NO APLICADOS salvo que se aporte evidencia.
    Este modulo NO implementa C2PA ni marca de agua: solo registra si otra
    herramienta lo hizo.
  - La firma de cada produccion y de cada pago queda guardada.
  - El secreto HMAC es obligatorio; la API escucha solo en 127.0.0.1.
  - Opcional: ligar la produccion a una voz y exigir que siga ACTIVA en el modulo 20.

NOTA LEGAL: el reparto 55/45, la comision de 15 % y la adquisicion son clausulas
comerciales. Deben ser revisadas por un abogado antes de publicarse.
"""
import os
import json
import sqlite3
from decimal import Decimal, ROUND_HALF_UP
from datetime import datetime, timezone
from pathlib import Path

import comun_seguridad as seg

DB_PATH = os.getenv("REPARTO_DB", "/workspace/repartos_v2.db")
BASE_DIR = os.getenv("BASE_DIR", "/workspace/projects/sistema_contenido_viral")
M7_DB = os.getenv("M7_DB", os.path.join(BASE_DIR, "database", "ai_news_studio.db"))

BP = 10000
BP_TITULAR = int(os.getenv("P_TITULAR_BP", "5500"))
BP_TECNOLOGIA = int(os.getenv("P_TECNOLOGIA_BP", "1500"))
BP_ADQ_PAGA = int(os.getenv("P_ADQ_PAGA_BP", "3000"))
BP_ADQ_RESERVA = int(os.getenv("P_ADQ_RESERVA_BP", "1500"))
MODO_ADQUISICION = os.getenv("MODO_ADQUISICION", "condicional_pago_inicial")
LICENCIA_VERSION = "1.0"

for _n, _v in (("P_TITULAR_BP", BP_TITULAR), ("P_TECNOLOGIA_BP", BP_TECNOLOGIA),
               ("P_ADQ_PAGA_BP", BP_ADQ_PAGA), ("P_ADQ_RESERVA_BP", BP_ADQ_RESERVA)):
    if not 0 <= _v <= BP:
        raise RuntimeError(f"{_n} fuera de rango (0..10000): {_v}")
BP_EMPRESA = BP - BP_TITULAR


# ---------------- dinero ----------------
def a_centavos(x):
    """'12.34' / 12.34 / Decimal -> 1234. Rechaza negativos y mas de 2 decimales significativos."""
    d = Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if d < 0:
        raise ValueError("monto negativo")
    return int(d * 100)


def de_centavos(c):
    return f"{Decimal(c) / 100:.2f}"


def _pct(centavos, bp):
    """Porcentaje en puntos base, redondeo mitad hacia arriba, solo enteros."""
    return (centavos * bp + BP // 2) // BP


# ---------------- esquema de IDs ----------------
def id_autor(pais, iniciales, fecha_nac_ddmmaa, secuencia):
    """ID de autor/cliente: RD + VOMA + 25564 + -02  ->  RDVOMA25564-02."""
    return "{}{}{}-{:02d}".format(pais.upper(), iniciales.upper(),
                                  str(fecha_nac_ddmmaa), int(secuencia))


def id_activo(id_autor_, secuencia):
    """ID de activo digital del autor: RDVOMA25564-02 + 01  ->  RDVOMA25564-0201."""
    return "{}{:02d}".format(id_autor_, int(secuencia))


def _now():
    return datetime.now(timezone.utc).isoformat()


def _db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("""CREATE TABLE IF NOT EXISTS producciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        huella TEXT UNIQUE NOT NULL, run_id TEXT, titular TEXT,
        doc_hash TEXT, asset_salida TEXT, contrato_hash TEXT, voz_fingerprint TEXT,
        licencia_version TEXT NOT NULL, split TEXT NOT NULL,
        licencia_voz TEXT NOT NULL, marca_contractual TEXT NOT NULL,
        disclosure_ia_aplicado INTEGER NOT NULL, disclosure_evidencia TEXT,
        c2pa_aplicado INTEGER NOT NULL, c2pa_evidencia TEXT,
        firma TEXT NOT NULL, creado TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS pagos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, huella TEXT NOT NULL,
        evento_id TEXT UNIQUE NOT NULL, moneda TEXT,
        monto_c INTEGER NOT NULL, titular_neto_c INTEGER NOT NULL,
        empresa_total_c INTEGER NOT NULL, comision_c INTEGER NOT NULL,
        detalle TEXT, firma TEXT NOT NULL, ts TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS adquisiciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT, huella TEXT,
        valor_c INTEGER, paga_ahora_c INTEGER, reserva_c INTEGER,
        pagador TEXT, evento_id TEXT, ts TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS eventos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, accion TEXT,
        detalle TEXT, resultado TEXT)""")
    con.commit()
    return con


def _evento(con, accion, detalle, resultado):
    con.execute("INSERT INTO eventos(ts,accion,detalle,resultado) VALUES(?,?,?,?)",
                (_now(), accion, detalle, resultado))
    con.commit()


def parametros():
    return {"titular_bp": BP_TITULAR, "empresa_bp": BP_EMPRESA,
            "tecnologia_bp": BP_TECNOLOGIA, "adq_paga_bp": BP_ADQ_PAGA,
            "adq_reserva_bp": BP_ADQ_RESERVA, "modo_adquisicion": MODO_ADQUISICION}


def crear_huella(run_id, titular, doc_hash):
    return "HV-" + seg.firma(f"huella|{run_id}|{titular}|{doc_hash}|{_now()}")[:32]


# ---------------- calculos (centavos enteros) ----------------
def calcular_reparto(monto_c):
    """Reparto 55/45 + comision tecnologica 15 % sobre lo del titular. Suma exacta."""
    monto_c = int(monto_c)
    titular_bruto = _pct(monto_c, BP_TITULAR)
    empresa_base = monto_c - titular_bruto
    comision = _pct(titular_bruto, BP_TECNOLOGIA)
    titular_neto = titular_bruto - comision
    empresa_total = empresa_base + comision
    assert titular_neto + empresa_total == monto_c
    return {"monto_c": monto_c, "titular_bruto_c": titular_bruto,
            "titular_neto_c": titular_neto, "empresa_base_c": empresa_base,
            "comision_tecnologica_c": comision, "empresa_total_c": empresa_total}


def calcular_adquisicion(valor_c, pago_inicial_c=None):
    """Adquisicion del activo por la empresa (la regla comercial debe confirmarla un abogado).

    Modos (MODO_ADQUISICION):
      - condicional_pago_inicial: sin pago inicial la empresa es propietaria del 45 %;
        con pago inicial la empresa solo reserva el 15 %.
      - sobre_produccion: paga 30 % + reserva 15 % del valor de la produccion.
      - sobre_empresa: 30 % y 15 % calculados sobre la cuota de la empresa.
    """
    valor_c = int(valor_c)
    if MODO_ADQUISICION == "condicional_pago_inicial":
        if not pago_inicial_c or int(pago_inicial_c) <= 0:
            emp = _pct(valor_c, BP_EMPRESA)
            return {"valor_c": valor_c, "paga_ahora_c": 0, "reserva_c": 0,
                    "empresa_c": emp, "total_empresa_c": emp,
                    "regla": "no_paga_empresa_45", "modo": MODO_ADQUISICION}
        emp = _pct(valor_c, BP_ADQ_RESERVA)
        return {"valor_c": valor_c, "paga_ahora_c": int(pago_inicial_c), "reserva_c": emp,
                "empresa_c": emp, "total_empresa_c": emp,
                "regla": "paga_empresa_reserva_15", "modo": MODO_ADQUISICION}
    base = _pct(valor_c, BP_EMPRESA) if MODO_ADQUISICION == "sobre_empresa" else valor_c
    paga, reserva = _pct(base, BP_ADQ_PAGA), _pct(base, BP_ADQ_RESERVA)
    return {"valor_c": valor_c, "paga_ahora_c": paga, "reserva_c": reserva,
            "total_empresa_c": paga + reserva, "modo": MODO_ADQUISICION}


# ---------------- verificacion de cobro (modulo 7) ----------------
def evento_cobrado(evento_id):
    """Devuelve (monto_c, moneda) si el modulo 7 confirmo el cobro; si no, lanza ValueError."""
    if not Path(M7_DB).exists():
        raise ValueError(f"no encuentro la base del modulo 7 ({M7_DB}); no se puede confirmar el cobro")
    con = sqlite3.connect(f"file:{M7_DB}?mode=ro", uri=True)
    try:
        r = con.execute("SELECT status, amount_cents, currency FROM payment_events_v2 "
                        "WHERE event_id=?", (evento_id,)).fetchone()
    finally:
        con.close()
    if not r:
        raise ValueError("el evento de pago no existe")
    if r[0] != "PROCESSED":
        raise ValueError(f"el cobro no esta confirmado (estado {r[0]})")
    return int(r[1]), r[2]


# ---------------- producciones, pagos, adquisiciones ----------------
def registrar_produccion(run_id, titular, asset_salida, doc_hash="", contrato_hash="",
                         marca_contractual=None, voz_fingerprint=None,
                         disclosure_ia_aplicado=False, disclosure_evidencia="",
                         c2pa_aplicado=False, c2pa_evidencia=""):
    """Registra una produccion. Las banderas de aviso de IA y C2PA solo valen 1 con evidencia."""
    if disclosure_ia_aplicado and not disclosure_evidencia:
        raise ValueError("disclosure_ia_aplicado requiere disclosure_evidencia (ruta o hash del archivo etiquetado)")
    if c2pa_aplicado and not c2pa_evidencia:
        raise ValueError("c2pa_aplicado requiere c2pa_evidencia (ruta o hash del manifiesto C2PA)")
    if voz_fingerprint:
        import pp_modulo_20_consentimiento as M20
        if not M20.voz_activa(voz_fingerprint):
            raise ValueError("la voz asociada no esta ACTIVA (revocada, borrada o inexistente)")
    huella = crear_huella(run_id, titular, doc_hash)
    if marca_contractual is None:
        marca_contractual = f"[{huella}] contrato-reparto-v{LICENCIA_VERSION}"
    split = json.dumps(parametros(), ensure_ascii=False, sort_keys=True)
    firma = seg.firma(f"{huella}|{titular}|{split}")
    con = _db()
    con.execute("INSERT INTO producciones(huella,run_id,titular,doc_hash,asset_salida,contrato_hash,"
                "voz_fingerprint,licencia_version,split,licencia_voz,marca_contractual,"
                "disclosure_ia_aplicado,disclosure_evidencia,c2pa_aplicado,c2pa_evidencia,firma,creado) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (huella, run_id, titular, doc_hash, asset_salida, contrato_hash, voz_fingerprint,
                 LICENCIA_VERSION, split, "LICENCIA_NO_CESION", marca_contractual,
                 1 if disclosure_ia_aplicado else 0, disclosure_evidencia,
                 1 if c2pa_aplicado else 0, c2pa_evidencia, firma, _now()))
    con.commit()
    _evento(con, "PRODUCCION", f"{huella} titular={titular}", "REGISTRADA")
    con.close()
    return {"huella": huella, "firma": firma, "split": parametros(),
            "marca_contractual_texto": marca_contractual,
            "licencia_voz": "LICENCIA_NO_CESION",
            "disclosure_ia_aplicado": bool(disclosure_ia_aplicado),
            "c2pa_aplicado": bool(c2pa_aplicado),
            "aviso": "La marca contractual es un texto de referencia; este modulo no la incrusta en el archivo."}


def registrar_pago(huella, evento_id):
    """Reparte un cobro CONFIRMADO. El monto sale del evento del modulo 7."""
    con = _db()
    prod = con.execute("SELECT 1 FROM producciones WHERE huella=?", (huella,)).fetchone()
    if not prod:
        con.close()
        return {"estado": "ERROR", "motivo": "huella no registrada"}
    try:
        monto_c, moneda = evento_cobrado(evento_id)
    except ValueError as e:
        con.close()
        return {"estado": "RECHAZADO", "motivo": str(e)}
    if con.execute("SELECT 1 FROM pagos WHERE evento_id=?", (evento_id,)).fetchone():
        con.close()
        return {"estado": "RECHAZADO", "motivo": "este cobro ya fue repartido"}
    r = calcular_reparto(monto_c)
    firma = seg.firma(f"{huella}|{evento_id}|{monto_c}|{r['titular_neto_c']}|{r['empresa_total_c']}")
    con.execute("INSERT INTO pagos(huella,evento_id,moneda,monto_c,titular_neto_c,empresa_total_c,"
                "comision_c,detalle,firma,ts) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (huella, evento_id, moneda, monto_c, r["titular_neto_c"], r["empresa_total_c"],
                 r["comision_tecnologica_c"], json.dumps(r), firma, _now()))
    con.commit()
    _evento(con, "PAGO", f"{huella} {evento_id} {de_centavos(monto_c)} {moneda}", "REPARTIDO")
    con.close()
    return {"estado": "OK", "huella": huella, "moneda": moneda, "firma": firma,
            "monto": de_centavos(monto_c), "titular_neto": de_centavos(r["titular_neto_c"]),
            "empresa_total": de_centavos(r["empresa_total_c"]),
            "comision_tecnologica": de_centavos(r["comision_tecnologica_c"])}


def registrar_adquisicion(valor_produccion, pagador, huella=None, pago_inicial=None, evento_id=None):
    valor_c = a_centavos(valor_produccion)
    pago_c = a_centavos(pago_inicial) if pago_inicial else 0
    if pago_c > 0:
        if not evento_id:
            return {"estado": "RECHAZADO", "motivo": "el pago inicial requiere evento_id de un cobro confirmado"}
        try:
            cobrado_c, _m = evento_cobrado(evento_id)
        except ValueError as e:
            return {"estado": "RECHAZADO", "motivo": str(e)}
        if cobrado_c < pago_c:
            return {"estado": "RECHAZADO", "motivo": "el cobro confirmado es menor que el pago inicial declarado"}
    a = calcular_adquisicion(valor_c, pago_c)
    con = _db()
    con.execute("INSERT INTO adquisiciones(huella,valor_c,paga_ahora_c,reserva_c,pagador,evento_id,ts) "
                "VALUES(?,?,?,?,?,?,?)",
                (huella, valor_c, a["paga_ahora_c"], a.get("reserva_c", 0), pagador, evento_id, _now()))
    con.commit()
    _evento(con, "ADQUISICION", f"pagador={pagador} valor={de_centavos(valor_c)}", "REGISTRADA")
    con.close()
    return {"estado": "OK", "pagador": pagador,
            **{(k[:-2] if k.endswith("_c") else k): (de_centavos(v) if k.endswith("_c") else v)
               for k, v in a.items()}}


def listar_producciones():
    con = _db()
    out = [dict(r) for r in con.execute(
        "SELECT huella,run_id,titular,asset_salida,voz_fingerprint,disclosure_ia_aplicado,"
        "c2pa_aplicado,creado FROM producciones ORDER BY id DESC")]
    con.close()
    return out


def listar_pagos(huella=None):
    con = _db()
    if huella:
        rows = con.execute("SELECT * FROM pagos WHERE huella=? ORDER BY id DESC", (huella,))
    else:
        rows = con.execute("SELECT * FROM pagos ORDER BY id DESC")
    out = [dict(r) for r in rows]
    con.close()
    return out


def eventos(limite=50):
    con = _db()
    out = [dict(r) for r in con.execute(
        "SELECT * FROM eventos ORDER BY id DESC LIMIT ?", (limite,))]
    con.close()
    return out


def crear_app():
    from fastapi import FastAPI, Form, HTTPException
    from fastapi.responses import JSONResponse
    seg.secreto()   # detiene el arranque si el secreto falta o es debil
    app = FastAPI(title="M22 Huella + Reparto")

    @app.get("/reparto/estado")
    def estado():
        return {"parametros": parametros(), "producciones": len(listar_producciones())}

    @app.get("/reparto/producciones")
    def producciones():
        return listar_producciones()

    @app.get("/reparto/pagos")
    def pagos(huella: str = None):
        return listar_pagos(huella)

    @app.get("/reparto/eventos")
    def _eventos(limite: int = 50):
        return eventos(limite)

    @app.post("/reparto/produccion")
    def produccion(run_id: str = Form(...), titular: str = Form(...),
                   asset_salida: str = Form(...), doc_hash: str = Form(""),
                   contrato_hash: str = Form(""), voz_fingerprint: str = Form(None),
                   disclosure_ia_aplicado: bool = Form(False), disclosure_evidencia: str = Form(""),
                   c2pa_aplicado: bool = Form(False), c2pa_evidencia: str = Form("")):
        try:
            return JSONResponse(registrar_produccion(
                run_id, titular, asset_salida, doc_hash, contrato_hash, None, voz_fingerprint,
                disclosure_ia_aplicado, disclosure_evidencia, c2pa_aplicado, c2pa_evidencia))
        except ValueError as e:
            raise HTTPException(400, str(e))

    @app.post("/reparto/pago")
    def pago(huella: str = Form(...), evento_id: str = Form(...)):
        return JSONResponse(registrar_pago(huella, evento_id))

    @app.post("/reparto/adquisicion")
    def adquisicion(valor_produccion: str = Form(...), pagador: str = Form(...),
                    huella: str = Form(None), pago_inicial: str = Form(None),
                    evento_id: str = Form(None)):
        return JSONResponse(registrar_adquisicion(valor_produccion, pagador, huella,
                                                  pago_inicial, evento_id))

    return app


if os.getenv("M22_HELP") == "1":
    print(json.dumps({"parametros": parametros(),
                      "ejemplo_1000": {k: de_centavos(v) for k, v in calcular_reparto(100000).items()}},
                     indent=2, ensure_ascii=False))


if __name__ == "__main__" and os.getenv("M22_API") == "1":
    import uvicorn
    uvicorn.run(crear_app(), host=seg.HOST_API, port=int(os.getenv("M22_PORT", "8092")))
