"""
Módulo 15 — Stack de IA Open Source + Gestión de GPU.

Registra TODO el catálogo de IA de código abierto que quieres usar (guiones, voz,
video, AR/render), con:
  - estado real de disponibilidad (binario/paquete/script),
  - gestión de VRAM y carga perezosa (lazy loading),
  - recomendación de modelo por tarea y por VRAM disponible.

No inventa comandos: detecta qué hay instalado y marca los puntos de conexión.
API FastAPI en puerto 8060 (interno).
"""
import os, json, shutil, subprocess, sqlite3
from datetime import datetime, timezone
from pathlib import Path

BASE_DIR = Path(os.getenv("STACK_BASE", "/workspace/projects/sistema_contenido_viral"))
DB_PATH = Path(os.getenv("STACK_DB", str(BASE_DIR / "database" / "ai_stack.db")))


def _now():
    return datetime.now(timezone.utc).isoformat()


def _conn():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(DB_PATH)); c.row_factory = sqlite3.Row
    return c


# Catálogo de IA open source solicitado (tarea -> modelos)
CATALOGO = {
    "guion": {
        "qwen2.5 (instruct)": {"tam": "7b-32b", "via": "ollama", "comando": "ollama"},
    },
    "vision": {
        "qwen2.5vl": {"tam": "7b", "via": "ollama", "comando": "ollama"},
    },
    "voz": {
        "chatterbox-multilingual (MIT)": {"via": "paquete", "modulo": "chatterbox"},
        "dots.tts (Apache-2.0, pendiente de probar)": {"via": "paquete", "modulo": "dots_tts"},
    },
    "imagen": {
        "flux.1-schnell (Apache-2.0)": {"via": "paquete", "modulo": "diffusers"},
    },
    "video": {
        "wan2.2-ti2v-5b": {"via": "script", "script": "run_wan.py"},
    },
    "lipsync": {
        "latentsync (codigo Apache-2.0; pesos OpenRAIL++)": {"via": "script", "script": "../run_latentsync.sh"},
    },
    "ar_render": {
        "nerfstudio": {"via": "binario", "comando": "ns-train"},
        "gaussian-splatting (splatfacto)": {"via": "binario", "comando": "ns-train"},
        "godot + openxr": {"via": "binario", "comando": "godot"},
    },
    "transcripcion": {
        "faster-whisper large-v3": {"via": "paquete", "modulo": "faster_whisper"},
    },
    "mux": {"ffmpeg": {"via": "binario", "comando": "ffmpeg"}},
}


def init_db():
    with _conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS stack_status (
            id INTEGER PRIMARY KEY AUTOINCREMENT, tarea TEXT, modelo TEXT,
            via TEXT, disponible INTEGER, detalle TEXT, ts TEXT
        );
        CREATE TABLE IF NOT EXISTS vram_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, total_mb INTEGER, usada_mb INTEGER,
            libre_mb INTEGER, ts TEXT
        );
        """)


def gpu_info():
    """Lee VRAM real de la GPU (si hay)."""
    info = {"disponible": False}
    try:
        if os.path.exists("/dev/nvidia0") or shutil.which("nvidia-smi"):
            if shutil.which("nvidia-smi"):
                out = subprocess.run(
                    ["nvidia-smi", "--query-gpu=name,memory.total,memory.used,memory.free",
                     "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=10).stdout.strip()
                if out:
                    nombre, tot, usada, libre = [x.strip() for x in out.split(",")[:4]]
                    info = {"disponible": True, "nombre": nombre,
                            "total_mb": int(tot), "usada_mb": int(usada), "libre_mb": int(libre)}
    except Exception as e:
        info["error"] = str(e)
    return info


def registrar_vram():
    g = gpu_info()
    if g.get("disponible"):
        init_db()
        with _conn() as c:
            c.execute("INSERT INTO vram_log (total_mb,usada_mb,libre_mb,ts) VALUES (?,?,?,?)",
                      (g["total_mb"], g["usada_mb"], g["libre_mb"], _now()))
    return g


def escanear_stack():
    """Detecta qué está realmente instalado (sin inventar)."""
    init_db()
    res = {}
    with _conn() as c:
        for tarea, modelos in CATALOGO.items():
            res[tarea] = {}
            for modelo, cfg in modelos.items():
                via = cfg.get("via")
                disp = False
                detalle = ""
                if via == "binario" or via == "ollama":
                    cmd = cfg.get("comando")
                    disp = bool(cmd) and shutil.which(cmd) is not None
                    detalle = f"binario '{cmd}' {'presente' if disp else 'ausente'}"
                elif via == "paquete":
                    import importlib.util
                    disp = importlib.util.find_spec(cfg.get("modulo", "")) is not None
                    detalle = f"paquete '{cfg.get('modulo')}' {'instalado' if disp else 'ausente'}"
                elif via == "script":
                    sc = cfg.get("script", "")
                    sp = BASE_DIR / sc[3:] if sc.startswith("../") else BASE_DIR / "_05_scripts" / sc
                    disp = sp.exists()
                    detalle = f"script {sp.name} {'presente' if disp else 'ausente'}"
                res[tarea][modelo] = {"disponible": disp, "detalle": detalle}
                c.execute("""INSERT INTO stack_status (tarea,modelo,via,disponible,detalle,ts)
                             VALUES (?,?,?,?,?,?)""",
                          (tarea, modelo, via, int(disp), detalle, _now()))
    return res


def recomendar(tarea, vram_libre_mb=24000):
    """Recomienda modelo según tarea y VRAM (heurística explicable)."""
    tabla = {
        "guion": [(24000, "qwen2.5:32b"), (0, "qwen2.5:7b-instruct")],
        "voz": [(0, "chatterbox-multilingual (MIT)")],
        "video": [(24000, "wan2.2-ti2v-5b")],
        "lipsync": [(8000, "latentsync")],
        "ar_render": [(24000, "gaussian-splatting (splatfacto)"), (0, "nerfstudio")],
    }
    for umbral, modelo in tabla.get(tarea, []):
        if vram_libre_mb >= umbral:
            return {"tarea": tarea, "modelo": modelo, "vram_libre_mb": vram_libre_mb}
    return {"tarea": tarea, "modelo": None, "vram_libre_mb": vram_libre_mb}


try:
    from fastapi import FastAPI
    app = FastAPI(title="Stack IA Open Source + GPU (pp_modulo_15)")

    @app.get("/gpu")
    def api_gpu():
        return gpu_info()

    @app.get("/stack")
    def api_stack():
        return escanear_stack()

    @app.get("/stack/recomendar")
    def api_rec(tarea: str):
        g = gpu_info()
        return recomendar(tarea, g.get("libre_mb", 0))
except Exception:
    app = None


if __name__ == "__main__":
    import uvicorn
    init_db()
    uvicorn.run(app, host="127.0.0.1", port=8060)
