#!/usr/bin/env bash
# Uso: run_latentsync.sh <video_o_foto> <audio> <salida.mp4>
# Corre LatentSync en su propio entorno. Una foto se convierte en un video de la
# duracion del audio; un video se repite hasta cubrir el audio.
set -euo pipefail
ENTRADA="${1:?falta video o foto}"; AUDIO="${2:?falta audio}"; SALIDA="${3:?falta salida}"
ENTRADA="$(realpath "$ENTRADA")"; AUDIO="$(realpath "$AUDIO")"; SALIDA="$(realpath -m "$SALIDA")"
LS_DIR="${LATENTSYNC_DIR:-/workspace/LatentSync}"
PY="${LATENTSYNC_PY:-/workspace/venv_latentsync/bin/python}"
CFG="${LATENTSYNC_CONFIG:-configs/unet/stage2.yaml}"
STEPS="${LS_STEPS:-20}"; GUIDE="${LS_GUIDANCE:-1.5}"
export HF_HOME="${HF_HOME:-/workspace/.cache/huggingface}"

[ -f "$LS_DIR/scripts/inference.py" ] || { echo "LatentSync no esta instalado en $LS_DIR (ejecuta instalar_latentsync.sh)" >&2; exit 2; }
[ -x "$PY" ] || { echo "falta el entorno $PY (ejecuta instalar_latentsync.sh)" >&2; exit 2; }
[ -f "$LS_DIR/checkpoints/latentsync_unet.pt" ] || { echo "falta $LS_DIR/checkpoints/latentsync_unet.pt" >&2; exit 2; }
[ -f "$LS_DIR/$CFG" ] || { echo "no existe la configuracion $CFG; disponibles:" >&2; ls "$LS_DIR/configs" "$LS_DIR/configs/unet" >&2 2>/dev/null; exit 2; }

DUR="$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$AUDIO")"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
case "${ENTRADA,,}" in
  *.jpg|*.jpeg|*.png|*.webp) PRE=(-loop 1 -i "$ENTRADA") ;;
  *) PRE=(-stream_loop -1 -i "$ENTRADA") ;;
esac
ffmpeg -y -loglevel error "${PRE[@]}" -t "$DUR" -r 25 -an -vf "scale=trunc(iw/2)*2:trunc(ih/2)*2" \
  -c:v libx264 -pix_fmt yuv420p "$TMP/entrada.mp4"

mkdir -p "$(dirname "$SALIDA")"
cd "$LS_DIR"
"$PY" -m scripts.inference --unet_config_path "$CFG" \
  --inference_ckpt_path checkpoints/latentsync_unet.pt \
  --inference_steps "$STEPS" --guidance_scale "$GUIDE" \
  --video_path "$TMP/entrada.mp4" --audio_path "$AUDIO" --video_out_path "$SALIDA"
[ -s "$SALIDA" ] || { echo "LatentSync no produjo $SALIDA" >&2; exit 3; }
