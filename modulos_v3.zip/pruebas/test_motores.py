import os, sys, tempfile, subprocess
AQUI = os.getenv("MODULOS_DIR", os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["MOTORES_BASE"] = tempfile.mkdtemp(); os.environ["MODELS_REPO"] = tempfile.mkdtemp(); os.environ["BASE_DIR"] = os.environ["MOTORES_BASE"]
sys.path.insert(0, AQUI)
import pp_modulo_17_motores as M17, pp_modulo_18_video as M18
import pp_modulo_15_stack_ia as M15
fallas = 0
def chk(n, c):
    global fallas
    print("OK   " if c else "FALLA", n); fallas += 0 if c else 1
chk("17 clonar sin consentimiento rechazado", M17.clonar_voz("hola", "x.wav", "o.wav")["estado"] == "RECHAZADO")
chk("17 consentimiento en blanco rechazado", M17.clonar_voz("hola", "x.wav", "o.wav", consentimiento_ref="  ")["estado"] == "RECHAZADO")
chk("17 idioma no soportado (bn)", M17.clonar_voz("hola", "x.wav", "o.wav", "bn", "CONSENT-1")["estado"] == "NO_SOPORTADO")
chk("17 transcribir sin modelo -> no simula", M17.transcribir("a.wav")["estado"] == "NO_DISPONIBLE")
chk("17 voz base en idioma sin soporte", M17.sintetizar_voz_base("hola", "o.wav", "bn")["estado"] == "NO_SOPORTADO")
chk("17 trocear respeta largo", all(len(t) <= 300 for t in M17._trocear("Frase uno. " * 60)))
chk("17 23 idiomas, sin bn", len(M17.idiomas_soportados()) == 23 and "bn" not in M17.idiomas_soportados())
chk("18 persona real sin consentimiento rechazada", M18.lipsync_latentsync("a.png", "a.wav", "o.mp4", es_persona_real=True)["estado"] == "RECHAZADO")
chk("18 sin LatentSync -> no simula", M18.lipsync_latentsync("a.png", "a.wav", "o.mp4")["estado"] == "NO_DISPONIBLE")
chk("18 flux sin modelo -> no simula", M18.generar_imagen_flux("x", "o.jpg")["estado"] == "NO_DISPONIBLE")
cat = M15.CATALOGO
chk("15 catalogo sin motores descartados", not any(k in str(cat).lower() for k in ("xtts", "fish", "wav2lip", "whisperx", "coder", "codestral", "mistral", "stable-video")))
print("fallas:", fallas); sys.exit(1 if fallas else 0)
