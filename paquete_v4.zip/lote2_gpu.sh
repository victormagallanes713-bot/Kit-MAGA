#!/usr/bin/env bash
# Sesion 2 en lotes.
#   bash lote2_gpu.sh ejecutar [fases]   -> CON GPU: corre sesion2_gpu.py en tmux (sesion "sesion2"). fases: caras,movimiento
# La instalacion de InfiniteTalk va aparte: bash instalar_infinitetalk.sh plan | instalar | pesos
set -uo pipefail
BASE="${BASE:-/workspace/projects/sistema_contenido_viral}"
VENV="${VENV_DIR:-/workspace/venv_ia}"
MODO="${1:-}"; FASES="${2:-caras,movimiento}"
mkdir -p "$BASE/logs"
[ -f "$VENV/bin/activate" ] && source "$VENV/bin/activate"
cd "$BASE" || exit 1

if [ "$MODO" = "ejecutar" ]; then
  command -v nvidia-smi >/dev/null && nvidia-smi -L >/dev/null 2>&1 || { echo "No hay GPU en este pod."; exit 1; }
  python3 -c "import torch,sys;sys.exit(0 if torch.cuda.is_available() else 1)" || { echo "PyTorch no ve la GPU."; exit 1; }
  if [ -z "${TMUX:-}" ] && [ -z "${LOTE_EN_TMUX:-}" ]; then
    command -v tmux >/dev/null || { echo "falta tmux (apt-get install -y tmux)"; exit 1; }
    tmux kill-session -t sesion2 2>/dev/null
    tmux new -d -s sesion2 "LOTE_EN_TMUX=1 bash '$0' ejecutar '$FASES'"
    echo "Lanzado en tmux (sigue aunque cierres el navegador). Ver avance:  tmux attach -t sesion2   (salir: Ctrl+B y luego D)"
    exit 0
  fi
  LOG="$BASE/logs/sesion2_$(date +%Y%m%d_%H%M).log"
  echo "Registro: $LOG"
  python3 sesion2_gpu.py --fases "$FASES" 2>&1 | tee "$LOG"; RC=${PIPESTATUS[0]}
  echo "Terminado con codigo $RC. El pod SIGUE ENCENDIDO (cobrando): detenlo desde My Pods cuando termines."
  read -r -p "Enter para cerrar" _ 2>/dev/null || true
  exit "$RC"
fi
echo "Uso: bash lote2_gpu.sh ejecutar [caras,movimiento]"; exit 2
