# Modulos corregidos 7, 11, 20, 21, 22 (v2)

Contenido: los 5 modulos, `comun_seguridad.py`, `instalar_modulos_v2.sh`, `pruebas/test_modulos.py`.

Que cambia (resumen):
- Secretos obligatorios (sin valores por defecto); el servicio no arranca sin ellos.
- M7: firma con timestamp en todos los proveedores, solo eventos `paid`, centavos enteros,
  monto = libro mayor, incentivos solo en la primera transicion a pagado, maximo 2 niveles.
- M11: sin acceso sin clave por loopback, auditoria en disco, limite de peticiones,
  query string, rutas seguras, Ollama restringido.
- M20: modelo ausente = error claro (no simula), umbral 0.75 SIN CALIBRAR, revocar y borrar.
- M21: la clonacion de voz ya no es obligatoria al inscribirse; hash de documento completo.
- M22: centavos enteros, pago solo con cobro confirmado en M7, C2PA/aviso de IA solo con evidencia.

Pendiente (no hecho aqui): descargar campplus.onnx, calibrar el umbral con audios reales,
adaptadores para Stripe/PayPal (requieren autorizar el proveedor), implementar C2PA/marca de agua,
revision legal del contrato y del reparto.
Las bases de datos nuevas tienen nombre *_v2.db y arrancan vacias.
