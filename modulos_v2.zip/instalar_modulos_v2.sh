#!/usr/bin/env bash
# Instala los modulos corregidos 7, 11, 20, 21 y 22 + comun_seguridad.py
# Uso (en el pod):  bash instalar_modulos_v2.sh
set -euo pipefail
BASE="${BASE:-/workspace/projects/sistema_contenido_viral}"
AQUI="$(cd "$(dirname "$0")" && pwd)"
MODS="pp_modulo_7.py pp_modulo_11_gateway.py pp_modulo_20_consentimiento.py pp_modulo_21_contrato.py pp_modulo_22_huella_reparto.py"
cd "$BASE"

R="$BASE/_respaldo_modulos_v1_$(date +%Y%m%d_%H%M)"
mkdir -p "$R"
for f in $MODS; do
  [ -f "$f" ] && cp -p "$f" "$R/" && echo "respaldo: $f"
  cp "$AQUI/$f" "$f"
done
cp "$AQUI/comun_seguridad.py" .
python3 -m py_compile comun_seguridad.py $MODS && echo "sintaxis OK"

# Secretos: se crean solo si faltan; nunca se muestran.
ENVF="$BASE/.env"
touch "$ENVF"; chmod 600 "$ENVF"
asegura() {  # variable, bytes
  local v
  v="$(grep -E "^$1=" "$ENVF" | tail -1 | cut -d= -f2- || true)"
  if [ "${#v}" -lt 24 ] || [ "$v" = "cambiar-en-produccion" ]; then
    sed -i "/^$1=/d" "$ENVF"
    echo "$1=$(openssl rand -hex "$2")" >> "$ENVF"
    echo "secreto creado: $1"
  else
    echo "secreto ya existe: $1"
  fi
}
asegura VOZ_HMAC_SECRET 32
asegura PAYMENT_WEBHOOK_SECRET 32
asegura GATEWAY_API_KEY 24
grep -q '^PAYMENT_PROVIDERS=' "$ENVF" || echo "PAYMENT_PROVIDERS=interno" >> "$ENVF"

echo; echo "== pruebas =="
MODULOS_DIR="$BASE" python3 "$AQUI/pruebas/test_modulos.py" | tail -4
echo; echo "Respaldo de los modulos anteriores en: $R"
