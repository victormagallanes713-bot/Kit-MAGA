"""
Modulo 20 - Consentimiento de voz y antifalsificacion (auditoria de similitud).  v2

Reglas:
  1. Quien registra una voz se IDENTIFICA y responde por ella (consentimiento
     firmado + declaracion de responsabilidad), voz por voz.
  2. Auditoria comparativa: si la voz entrante es muy similar a una ya
     registrada, se RECHAZA (evita suplantacion).
  3. Todo queda auditado.
  4. El titular puede REVOCAR su voz y pedir su BORRADO.

Cambios respecto a v1:
  - El secreto HMAC es obligatorio (sin valor por defecto).
  - El documento de identidad se guarda solo como HMAC, nunca en claro.
  - Si falta el modelo campplus.onnx el modulo FALLA con un mensaje claro;
    nunca finge que verifico.
  - Umbral por defecto 0.75 y marcado como NO CALIBRADO. 0.95 solo detectaba
    copias casi identicas del mismo archivo. Calibrar con `calibrar()`.
  - Nuevas funciones: revocar_voz y borrar_voz (+ endpoints).
  - La API escucha solo en 127.0.0.1.

Similitud de voz = coseno entre embeddings (campplus.onnx, 192 dim).
"""
import os
import json
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime, timezone

import comun_seguridad as seg

MODELS = Path(os.getenv("MODELS_REPO", "/workspace/models_repository"))
CAMPP_A_ONNX = Path(os.getenv("CAMPP_ONNX", str(MODELS / "cosyvoice2" / "campplus.onnx")))
DB_PATH = os.getenv("VOZ_DB", "/workspace/consentimiento_voz_v2.db")
UMBRAL = float(os.getenv("VOZ_UMBRAL_SIMILITUD", "0.75"))
UMBRAL_CALIBRADO = os.getenv("VOZ_UMBRAL_CALIBRADO", "0") == "1"

_session = None


def _now():
    return datetime.now(timezone.utc).isoformat()


# ---------- base de datos ----------
def _db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("""CREATE TABLE IF NOT EXISTS voces (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL, doc_hash TEXT NOT NULL, email TEXT,
        fingerprint TEXT UNIQUE NOT NULL, embedding TEXT,
        consent_ok INTEGER NOT NULL, accept_responsabilidad INTEGER NOT NULL,
        firma TEXT NOT NULL, creado TEXT NOT NULL, estado TEXT NOT NULL,
        motivo TEXT, revocado_ts TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS auditoria (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, accion TEXT,
        nombre TEXT, fingerprint TEXT, similitud REAL,
        contra_fingerprint TEXT, resultado TEXT, detalle TEXT)""")
    con.commit()
    return con


def _audit(con, accion, nombre, fp, similitud, contra, resultado, detalle=""):
    con.execute("INSERT INTO auditoria(ts,accion,nombre,fingerprint,similitud,"
                "contra_fingerprint,resultado,detalle) VALUES(?,?,?,?,?,?,?,?)",
                (_now(), accion, nombre, fp, similitud, contra, resultado, detalle))
    con.commit()


# ---------- embedding ----------
def _requerir_modelo():
    if not CAMPP_A_ONNX.exists():
        raise RuntimeError(
            f"Falta el modelo de voz {CAMPP_A_ONNX}. Sin el, esta auditoria no puede "
            f"funcionar y NO se simula. Descargalo con: "
            f"hf download FunAudioLLM/CosyVoice2-0.5B campplus.onnx "
            f"--local-dir {CAMPP_A_ONNX.parent}  (verifica el nombre con ls y revisa su licencia)")


def _embedding(wav):
    global _session
    _requerir_modelo()
    import sys
    for p in ("/workspace/CosyVoice", "/workspace/CosyVoice/third_party/Matcha-TTS"):
        if p not in sys.path:
            sys.path.insert(0, p)
    import numpy as np
    from cosyvoice.utils.file_utils import load_wav
    import torchaudio.compliance.kaldi as kaldi
    if _session is None:
        import onnxruntime as ort
        _session = ort.InferenceSession(str(CAMPP_A_ONNX),
                                        providers=["CPUExecutionProvider"])
    speech = load_wav(str(wav), 16000)
    feat = kaldi.fbank(speech, num_mel_bins=80, dither=0, sample_frequency=16000)
    feat = feat - feat.mean(dim=0, keepdim=True)
    emb = _session.run(None, {_session.get_inputs()[0].name:
                              feat.unsqueeze(dim=0).cpu().numpy()})[0].flatten()
    n = np.linalg.norm(emb)
    return (emb / n if n else emb).tolist()


def _cos(a, b):
    return float(sum(x * y for x, y in zip(a, b)))


def calibrar(misma_voz, distintas):
    """Ayuda para fijar el umbral con audios reales.

    misma_voz : lista de pares (wav_a, wav_b) de la MISMA persona.
    distintas : lista de pares (wav_a, wav_b) de personas DISTINTAS.
    Devuelve los coseno de cada grupo; el umbral debe quedar entre el maximo de
    'distintas' y el minimo de 'misma_voz'. Luego exporta VOZ_UMBRAL_SIMILITUD y
    VOZ_UMBRAL_CALIBRADO=1.
    """
    def _par(p):
        return round(_cos(_embedding(p[0]), _embedding(p[1])), 4)
    s = [_par(p) for p in misma_voz]
    d = [_par(p) for p in distintas]
    return {"misma_voz": s, "distintas": d,
            "sugerencia": (min(s) + max(d)) / 2 if s and d and min(s) > max(d) else None,
            "separables": bool(s and d and min(s) > max(d))}


# ---------- registro / verificacion ----------
def registrar_voz(nombre, doc, wav_ref, consent_ok, accept_responsabilidad, email=""):
    """Registra una voz tras verificar consentimiento + antifalsificacion."""
    if not nombre or not doc:
        return {"estado": "RECHAZADO", "motivo": "faltan nombre o documento (identificacion obligatoria)"}
    if not (consent_ok and accept_responsabilidad):
        return {"estado": "RECHAZADO",
                "motivo": "sin consentimiento firmado y/o sin aceptar la responsabilidad"}
    if not Path(wav_ref).exists():
        return {"estado": "ERROR", "motivo": f"no existe el wav: {wav_ref}"}
    dh = seg.hash_documento(doc)               # falla si no hay secreto
    emb = _embedding(wav_ref)                  # falla si no hay modelo
    fp = hashlib.sha256((nombre + "|" + dh).encode()).hexdigest()[:16]
    con = _db()
    if con.execute("SELECT 1 FROM voces WHERE fingerprint=? AND estado='ACTIVA'", (fp,)).fetchone():
        con.close()
        return {"estado": "RECHAZADO", "motivo": "este titular ya tiene una voz activa registrada"}
    peor, contra = 0.0, None
    for r in con.execute("SELECT fingerprint,embedding FROM voces WHERE estado='ACTIVA'"):
        sim = _cos(emb, json.loads(r["embedding"]))
        if sim > peor:
            peor, contra = sim, r["fingerprint"]
    if peor >= UMBRAL:
        _audit(con, "REGISTRO", nombre, fp, peor, contra, "RECHAZADO",
               f"similitud {peor:.3f} >= umbral {UMBRAL}")
        con.close()
        return {"estado": "RECHAZADO",
                "motivo": f"voz {peor*100:.1f}% similar a {contra} (umbral {UMBRAL*100:.0f}%)",
                "similitud": peor, "contra": contra, "umbral_calibrado": UMBRAL_CALIBRADO}
    firma = seg.firma(f"{nombre}|{dh}|{fp}")
    con.execute("INSERT INTO voces(nombre,doc_hash,email,fingerprint,embedding,consent_ok,"
                "accept_responsabilidad,firma,creado,estado,motivo) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (nombre, dh, email, fp, json.dumps(emb), 1, 1, firma, _now(), "ACTIVA", ""))
    _audit(con, "REGISTRO", nombre, fp, peor, contra, "ACTIVO", f"similitud max {peor:.3f}")
    con.close()
    return {"estado": "ACTIVO", "fingerprint": fp, "firma": firma,
            "similitud_max": peor, "umbral_calibrado": UMBRAL_CALIBRADO}


def verificar_voz(wav_ref, umbral=None):
    """Auditoria: la voz entrante se parece a alguna registrada?"""
    umbral = UMBRAL if umbral is None else float(umbral)
    if not Path(wav_ref).exists():
        return {"estado": "ERROR", "motivo": f"no existe el wav: {wav_ref}"}
    emb = _embedding(wav_ref)
    con = _db()
    mejor, contra, nombre = 0.0, None, None
    for r in con.execute("SELECT nombre,fingerprint,embedding FROM voces WHERE estado='ACTIVA'"):
        sim = _cos(emb, json.loads(r["embedding"]))
        if sim > mejor:
            mejor, contra, nombre = sim, r["fingerprint"], r["nombre"]
    rechaza = mejor >= umbral
    _audit(con, "VERIFICACION", nombre or "?", contra, mejor, contra,
           "RECHAZADO" if rechaza else "ACEPTADO", f"umbral {umbral}")
    con.close()
    return {"estado": "RECHAZADO" if rechaza else "ACEPTADO",
            "similitud": round(mejor, 4), "coincide_con": nombre if rechaza else None,
            "fingerprint": contra, "umbral": umbral, "umbral_calibrado": UMBRAL_CALIBRADO}


# ---------- revocacion y borrado ----------
def revocar_voz(fingerprint, motivo="solicitud del titular"):
    """La voz deja de contar para la auditoria y no puede usarse para produccion."""
    con = _db()
    r = con.execute("SELECT nombre,estado FROM voces WHERE fingerprint=?", (fingerprint,)).fetchone()
    if not r:
        con.close()
        return {"estado": "ERROR", "motivo": "fingerprint no existe"}
    con.execute("UPDATE voces SET estado='REVOCADA', motivo=?, revocado_ts=? WHERE fingerprint=?",
                (motivo, _now(), fingerprint))
    _audit(con, "REVOCACION", r["nombre"], fingerprint, None, None, "REVOCADA", motivo)
    con.close()
    return {"estado": "REVOCADA", "fingerprint": fingerprint}


def borrar_voz(fingerprint, motivo="solicitud de borrado del titular"):
    """Borra el embedding y los datos personales. Se conserva una linea de auditoria
    solo con el fingerprint (sin nombre ni documento) como prueba de que se borro."""
    con = _db()
    r = con.execute("SELECT nombre FROM voces WHERE fingerprint=?", (fingerprint,)).fetchone()
    if not r:
        con.close()
        return {"estado": "ERROR", "motivo": "fingerprint no existe"}
    con.execute("UPDATE voces SET embedding=NULL, nombre='[borrado]', email='', doc_hash='', "
                "estado='BORRADA', motivo=?, revocado_ts=? WHERE fingerprint=?",
                (motivo, _now(), fingerprint))
    _audit(con, "BORRADO", "[borrado]", fingerprint, None, None, "BORRADA", motivo)
    con.close()
    return {"estado": "BORRADA", "fingerprint": fingerprint,
            "nota": "Los audios originales y las producciones ya generadas se retiran por separado (M8/M21)."}


def voz_activa(fingerprint):
    """Las producciones deben llamar a esto antes de usar una voz."""
    con = _db()
    r = con.execute("SELECT 1 FROM voces WHERE fingerprint=? AND estado='ACTIVA'", (fingerprint,)).fetchone()
    con.close()
    return bool(r)


def listar():
    con = _db()
    out = [dict(r) for r in con.execute(
        "SELECT id,nombre,fingerprint,creado,estado FROM voces ORDER BY id DESC")]
    con.close()
    return out


def auditoria(limite=50):
    con = _db()
    out = [dict(r) for r in con.execute(
        "SELECT * FROM auditoria ORDER BY id DESC LIMIT ?", (limite,))]
    con.close()
    return out


def estado():
    return {"umbral": UMBRAL, "umbral_calibrado": UMBRAL_CALIBRADO,
            "modelo": str(CAMPP_A_ONNX), "modelo_presente": CAMPP_A_ONNX.exists(),
            "voces": len(listar())}


# ---------- API HTTP (solo loopback; sale al exterior por el gateway) ----------
def crear_app():
    from fastapi import FastAPI, UploadFile, File, Form
    from fastapi.responses import JSONResponse
    import tempfile
    import shutil
    seg.secreto()   # detiene el arranque si el secreto falta o es debil
    app = FastAPI(title="M20 Consentimiento de Voz")

    def _a_temporal(wav):
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as t:
            shutil.copyfileobj(wav.file, t)
            return t.name

    @app.get("/voz/estado")
    def _estado():
        return estado()

    @app.get("/voz/listar")
    def _listar():
        return listar()

    @app.get("/voz/auditoria")
    def _auditoria(limite: int = 50):
        return auditoria(limite)

    @app.post("/voz/registrar")
    async def registrar(nombre: str = Form(...), doc: str = Form(...),
                        consent_ok: bool = Form(...),
                        accept_responsabilidad: bool = Form(...),
                        email: str = Form(""), wav: UploadFile = File(...)):
        ruta = _a_temporal(wav)
        try:
            return JSONResponse(registrar_voz(nombre, doc, ruta, consent_ok,
                                              accept_responsabilidad, email))
        finally:
            Path(ruta).unlink(missing_ok=True)

    @app.post("/voz/verificar")
    async def verificar(wav: UploadFile = File(...), umbral: float = Form(None)):
        ruta = _a_temporal(wav)
        try:
            return JSONResponse(verificar_voz(ruta, umbral))
        finally:
            Path(ruta).unlink(missing_ok=True)

    @app.post("/voz/revocar")
    def _revocar(fingerprint: str = Form(...), motivo: str = Form("solicitud del titular")):
        return JSONResponse(revocar_voz(fingerprint, motivo))

    @app.post("/voz/borrar")
    def _borrar(fingerprint: str = Form(...), motivo: str = Form("solicitud de borrado del titular")):
        return JSONResponse(borrar_voz(fingerprint, motivo))

    @app.get("/voz/activa/{fingerprint}")
    def _activa(fingerprint: str):
        return {"fingerprint": fingerprint, "activa": voz_activa(fingerprint)}

    return app


if __name__ == "__main__" and os.getenv("M20_API") == "1":
    import uvicorn
    uvicorn.run(crear_app(), host=seg.HOST_API, port=int(os.getenv("M20_PORT", "8090")))
