"""
Modulo 11 - Gateway de seguridad (unico punto publico).  v2

Cambios respecto a v1:
  - Se elimina el acceso sin clave desde 127.0.0.1 (ALLOW_INTERNAL): detras de un
    proxy local todo parecia "interno". Los servicios internos se hablan entre si
    directamente; quien pase por el gateway lleva siempre la clave.
  - GATEWAY_API_KEY es obligatoria (minimo 24 caracteres); sin ella no arranca.
  - Auditoria en disco (JSONL) ademas de la memoria; no se guardan claves ni cuerpos.
  - Se reenvia la query string.
  - Limite de peticiones por clave+IP (GW_RATE_PER_MIN, por defecto 120).
  - Se rechazan rutas con "..", y a Ollama solo se le permiten rutas de uso
    (no pull/delete/create de modelos).
  - La respuesta del servicio se devuelve tal cual (tipo y bytes), no solo JSON.
  - La llamada al servicio ya no bloquea el bucle de eventos.

Puerto: 8080. Es el unico servicio que puede escuchar fuera de 127.0.0.1.
"""
import os
import hmac
import json
import time
import threading
import urllib.request
import urllib.error
from collections import defaultdict, deque
from pathlib import Path

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import Response

BASE_DIR = Path(os.getenv("BASE_DIR", "/workspace/projects/sistema_contenido_viral"))
AUDIT_FILE = Path(os.getenv("GW_AUDIT_FILE", str(BASE_DIR / "database" / "gateway_audit.jsonl")))
RATE_PER_MIN = int(os.getenv("GW_RATE_PER_MIN", "120"))
TIMEOUT_S = int(os.getenv("GW_TIMEOUT_S", "60"))

SERVICIOS = {
    "activos": "http://127.0.0.1:8010",
    "agentes": "http://127.0.0.1:8020",
    "produccion": "http://127.0.0.1:8030",
    "ollama": "http://127.0.0.1:11434",
    "modulo7": "http://127.0.0.1:8000",
    "whatsapp": "http://127.0.0.1:8040",
    "orquestador": "http://127.0.0.1:8050",
    "stack": "http://127.0.0.1:8060",
    "n8n": "http://127.0.0.1:8070",
    "n8nui": "http://127.0.0.1:5678",
    "voz": "http://127.0.0.1:8090",
    "contrato": "http://127.0.0.1:8091",
    "reparto": "http://127.0.0.1:8092",
    "i18n": "http://127.0.0.1:8093",
}

# Rutas permitidas por servicio (prefijos). Sin entrada = todas las del servicio.
RUTAS_PERMITIDAS = {
    "ollama": ("api/generate", "api/chat", "api/tags", "api/embeddings", "api/embed", "api/show"),
}

# El webhook de pagos lo firma el proveedor y no lleva la clave del gateway: se
# expone aparte, solo esa ruta, y se valida en el propio modulo 7.
RUTAS_SIN_CLAVE = {("modulo7", "webhook/")}

app = FastAPI(title="Gateway de Seguridad (pp_modulo_11) v2")

_audit_mem = deque(maxlen=500)
_lock = threading.Lock()
_ventanas = defaultdict(deque)


def _api_key():
    k = os.getenv("GATEWAY_API_KEY", "").strip()
    if len(k) < 24:
        raise RuntimeError("Falta GATEWAY_API_KEY (minimo 24 caracteres). El gateway no arranca sin clave. "
                           "Generala con: python3 -c \"import secrets;print(secrets.token_urlsafe(32))\"")
    return k


@app.on_event("startup")
def _arranque():
    _api_key()
    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)


def _ip(request: Request):
    return request.client.host if request.client else "?"


def _clave_ok(x_api_key):
    if not x_api_key:
        return False
    return hmac.compare_digest(x_api_key.encode("utf-8"), _api_key().encode("utf-8"))


def _limite_ok(clave_id: str) -> bool:
    ahora = time.time()
    with _lock:
        d = _ventanas[clave_id]
        while d and ahora - d[0] > 60:
            d.popleft()
        if len(d) >= RATE_PER_MIN:
            return False
        d.append(ahora)
        return True


def _auditar(ev: dict):
    with _lock:
        _audit_mem.append(ev)
        try:
            with AUDIT_FILE.open("a", encoding="utf-8") as f:
                f.write(json.dumps(ev, ensure_ascii=False) + "\n")
        except Exception:
            pass  # la auditoria en memoria sigue disponible


def _ruta_segura(servicio: str, path: str) -> bool:
    partes = [p for p in path.split("/") if p]
    if ".." in partes or "\\" in path or "\x00" in path:
        return False
    prefijos = RUTAS_PERMITIDAS.get(servicio)
    if prefijos is None:
        return True
    p = "/".join(partes)
    return any(p == x or p.startswith(x + "/") for x in prefijos)


def _forward(target: str, path: str, query: str, method: str, body, headers: dict):
    url = f"{target}{path}" + (f"?{query}" if query else "")
    req = urllib.request.Request(url, data=body, method=method)
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as r:
            return r.status, r.read(), r.headers.get("content-type", "application/octet-stream")
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers.get("content-type", "application/json")
    except Exception as e:  # noqa: BLE001
        return 502, json.dumps({"error": f"servicio no disponible: {type(e).__name__}"}).encode(), "application/json"


@app.get("/health")
def health():
    return {"ok": True, "servicios": list(SERVICIOS.keys()), "auth_requerida": True,
            "limite_por_minuto": RATE_PER_MIN}


@app.get("/auditoria")
def auditoria(request: Request, x_api_key: str | None = Header(default=None)):
    if not _clave_ok(x_api_key):
        raise HTTPException(401, "no autorizado")
    return {"eventos": list(_audit_mem)[-100:], "archivo": str(AUDIT_FILE)}


@app.api_route("/s/{servicio}/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def proxy(servicio: str, path: str, request: Request,
                x_api_key: str | None = Header(default=None),
                x_manifest: str | None = Header(default=None)):
    ip = _ip(request)
    sin_clave = any(servicio == s and path.startswith(p) for s, p in RUTAS_SIN_CLAVE)
    autorizado = sin_clave or _clave_ok(x_api_key)
    ev = {"ts": round(time.time(), 3), "ip": ip, "servicio": servicio, "path": path,
          "metodo": request.method, "ok": autorizado}
    if not autorizado:
        _auditar({**ev, "motivo": "clave ausente o incorrecta"})
        raise HTTPException(401, "no autorizado")
    if not _limite_ok(f"{ip}|{(x_api_key or 'sin-clave')[:6]}"):
        _auditar({**ev, "ok": False, "motivo": "limite de peticiones"})
        raise HTTPException(429, "demasiadas peticiones")
    if servicio not in SERVICIOS:
        _auditar({**ev, "ok": False, "motivo": "servicio desconocido"})
        raise HTTPException(404, f"servicio desconocido: {servicio}")
    if not _ruta_segura(servicio, path):
        _auditar({**ev, "ok": False, "motivo": "ruta no permitida"})
        raise HTTPException(403, "ruta no permitida")

    body = await request.body()
    hdrs = {"content-type": request.headers.get("content-type", "application/json")}
    if x_manifest:
        hdrs["x-manifest"] = x_manifest
    for h in ("x-timestamp", "x-signature"):          # firma del proveedor de pagos
        if request.headers.get(h):
            hdrs[h] = request.headers[h]
    status, data, ctype = await run_in_threadpool(
        _forward, SERVICIOS[servicio], "/" + path, request.url.query,
        request.method, body or None, hdrs)
    _auditar({**ev, "status": status})
    return Response(content=data, status_code=status, media_type=ctype)
