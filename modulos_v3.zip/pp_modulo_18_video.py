"""
Modulo 18 - Motores de video (Flux + LatentSync + ffmpeg).  v2

Cambios respecto a v1:
  - Lip-sync: LatentSync (codigo Apache-2.0; pesos con licencia OpenRAIL++, con
    restricciones de uso que deben trasladarse a quien use los videos; pendiente
    de revision legal) en lugar de Wav2Lip (licencia restringida).
  - Se llama a run_latentsync.sh, que corre en su propio entorno (venv_latentsync).
  - Exige consentimiento documentado para animar una cara: si la cara es de una
    persona real, no se anima sin consentimiento_ref. Nunca se anima ni caricaturiza
    a menores reales.
  - Nada se simula: sin LatentSync instalado devuelve NO_DISPONIBLE con la causa.
"""
import os
import shutil
import subprocess
from pathlib import Path

MODELS = Path(os.getenv("MODELS_REPO", "/workspace/models_repository"))
FLUX_DIR = os.getenv("FLUX_DIR", str(MODELS / "flux"))
BASE = Path(os.getenv("MOTORES_BASE", "/workspace/projects/sistema_contenido_viral"))
LS_SCRIPT = Path(os.getenv("LATENTSYNC_SCRIPT", str(BASE / "run_latentsync.sh")))
LS_DIR = Path(os.getenv("LATENTSYNC_DIR", "/workspace/LatentSync"))
TMP = Path(os.getenv("MOTORES_TMP", "/workspace/tmp"))


def _pip_ok(modulo):
    import importlib.util
    return importlib.util.find_spec(modulo) is not None


def generar_imagen_flux(prompt, salida, pasos=4, alto=768, ancho=768, seed=None):
    """Genera una imagen con FLUX.1-schnell (Apache-2.0). Para rostros INVENTADOS de avatares."""
    if not _pip_ok("diffusers"):
        return {"motor": "flux", "estado": "NO_DISPONIBLE", "detalle": "paquete diffusers no instalado"}
    if not Path(FLUX_DIR, "model_index.json").exists():
        return {"motor": "flux", "estado": "NO_DISPONIBLE", "detalle": f"falta el modelo en {FLUX_DIR}"}
    import torch
    from diffusers import FluxPipeline
    Path(salida).parent.mkdir(parents=True, exist_ok=True)
    g = torch.Generator("cuda").manual_seed(seed) if seed is not None else None
    pipe = FluxPipeline.from_pretrained(FLUX_DIR, torch_dtype=torch.bfloat16)
    pipe.enable_model_cpu_offload()
    try:
        img = pipe(prompt, num_inference_steps=pasos, guidance_scale=0.0,
                   height=alto, width=ancho, generator=g).images[0]
        img.save(salida)
    finally:
        del pipe
        torch.cuda.empty_cache()
    return {"motor": "flux", "estado": "OK", "salida": str(salida), "pasos": pasos,
            "resolucion": f"{ancho}x{alto}", "seed": seed}


def lipsync_latentsync(face, audio, salida, consentimiento_ref=None, es_persona_real=False,
                       pasos=20, guidance=1.5, timeout=3600):
    """Anima una cara (foto o video) con el audio usando LatentSync."""
    if es_persona_real and not (consentimiento_ref and str(consentimiento_ref).strip()):
        return {"motor": "latentsync", "estado": "RECHAZADO",
                "detalle": "la cara es de una persona real y falta consentimiento_ref"}
    if not LS_SCRIPT.exists():
        return {"motor": "latentsync", "estado": "NO_DISPONIBLE", "detalle": f"falta {LS_SCRIPT}"}
    if not (LS_DIR / "scripts" / "inference.py").exists():
        return {"motor": "latentsync", "estado": "NO_DISPONIBLE",
                "detalle": f"LatentSync no esta instalado en {LS_DIR}: ejecuta instalar_latentsync.sh"}
    for p in (face, audio):
        if not Path(p).exists():
            return {"motor": "latentsync", "estado": "ERROR", "detalle": f"no existe: {p}"}
    Path(salida).parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, LS_STEPS=str(pasos), LS_GUIDANCE=str(guidance))
    p = subprocess.run(["bash", str(LS_SCRIPT), str(face), str(audio), str(salida)],
                       capture_output=True, text=True, timeout=timeout, env=env)
    ok = p.returncode == 0 and Path(salida).exists() and Path(salida).stat().st_size > 0
    return {"motor": "latentsync", "estado": "OK" if ok else "ERROR", "salida": str(salida),
            "returncode": p.returncode, "stderr_tail": "" if ok else (p.stderr or p.stdout)[-600:]}


def armar_escena(prompt_personaje, audio, salida_video, seed=None, consentimiento_ref=None):
    """Flux inventa el personaje -> LatentSync lo anima con el audio."""
    TMP.mkdir(parents=True, exist_ok=True)
    tmp_img = str(TMP / "personaje.jpg")
    tmp_lip = str(TMP / "personaje_lipsync.mp4")
    r_img = generar_imagen_flux(prompt_personaje, tmp_img, seed=seed)
    if r_img.get("estado") != "OK":
        return {"pasos": [r_img], "estado": "FALLO_IMAGEN"}
    r_lip = lipsync_latentsync(tmp_img, audio, tmp_lip, consentimiento_ref, es_persona_real=False)
    if r_lip.get("estado") != "OK":
        return {"pasos": [r_img, r_lip], "estado": "FALLO_LIPSYNC"}
    Path(salida_video).parent.mkdir(parents=True, exist_ok=True)
    if not shutil.which("ffmpeg"):
        return {"pasos": [r_img, r_lip], "estado": "FALLO_MUX", "detalle": "ffmpeg ausente"}
    r = subprocess.run(["ffmpeg", "-y", "-i", tmp_lip, "-c:v", "libx264", "-c:a", "aac",
                        "-pix_fmt", "yuv420p", str(salida_video)], capture_output=True, text=True, timeout=1800)
    if r.returncode != 0:
        return {"pasos": [r_img, r_lip], "estado": "FALLO_MUX", "detalle": r.stderr[-300:]}
    return {"pasos": [r_img, r_lip], "estado": "OK", "salida": str(salida_video)}


def estado_motores():
    return {
        "flux": {"listo": _pip_ok("diffusers") and Path(FLUX_DIR, "model_index.json").exists(), "dir": FLUX_DIR},
        "latentsync": {"listo": LS_SCRIPT.exists() and (LS_DIR / "scripts" / "inference.py").exists(),
                       "script": str(LS_SCRIPT), "codigo": str(LS_DIR)},
    }


if __name__ == "__main__":
    import json
    print(json.dumps(estado_motores(), indent=2, ensure_ascii=False))
