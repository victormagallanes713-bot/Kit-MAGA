"""
Modulo 7 - Pagos (webhook) + conciliacion.  v2

Cambios respecto a v1:
  - Firma obligatoria en TODOS los proveedores: HMAC-SHA256 de "<timestamp>.<cuerpo>"
    con cabeceras X-Timestamp y X-Signature, y ventana de 5 minutos contra repeticiones.
    Los proveedores permitidos se declaran en PAYMENT_PROVIDERS; cualquier otro se rechaza.
  - Solo se actua sobre eventos con "status": "paid".
  - Dinero en CENTAVOS enteros. El monto del evento debe coincidir con el del libro
    mayor (FinancialLedger.monto); si no coincide, se rechaza y no se paga nada.
  - El libro mayor solo pasa de pendiente a pagado una vez. Los incentivos
    multinivel solo se generan en esa transicion (un segundo evento para la misma
    transaccion no vuelve a pagar a nadie).
  - Incentivos: maximo 2 niveles (el plano dice 1 a 2), sobre el monto del libro mayor.
  - Cada paso queda anotado; si algo falla el evento queda FAILED y se puede
    reintentar sin repetir los pasos ya hechos.
  - Estado final PROCESSED (lo usa el modulo 22 para confirmar cobros).
  - Tabla nueva payment_events_v2; no se crea nada al importar el modulo.

AVISO: esto es un receptor generico firmado. Stripe, PayPal u otros tienen su
propio formato de firma y de evento; para usarlos hace falta un adaptador que
traduzca su evento a este formato. No esta implementado y requiere que autorices
el proveedor (APIs externas).

Dependencias del proyecto (modulos 4, 5, 6 e init_db) sin cambios.
"""
import os
import hmac
import json
import time
import hashlib
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import Optional, Dict, Any

from fastapi import FastAPI, Request, Header, HTTPException, BackgroundTasks
from sqlalchemy import Column, String, DateTime, Integer, JSON, create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.exc import IntegrityError

BASE_DIR = os.getenv("BASE_DIR", "/workspace/projects/sistema_contenido_viral")
DB_PATH = os.getenv("DB_PATH", os.path.join(BASE_DIR, "database", "ai_news_studio.db"))
engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

from init_db import FinancialLedger  # noqa: E402  (modelo del libro mayor del proyecto)
from pp_modulo_4 import liberar_si_pagado  # noqa: E402
from pp_modulo_5 import order_credit_tokens_after_fiat_paid  # noqa: E402
from pp_modulo_6 import mlm_record_event, mlm_payout  # noqa: E402

PROVEEDORES = {p.strip() for p in os.getenv("PAYMENT_PROVIDERS", "interno").split(",") if p.strip()}
VENTANA_S = int(os.getenv("PAYMENT_WINDOW_S", "300"))
MLM_MAX_NIVELES = 2
MLM_PCTS = [float(x) for x in os.getenv("MLM_PCTS", "0.10,0.05").split(",") if x.strip()][:MLM_MAX_NIVELES]

PASOS = ("ledger_pagado", "tokens", "liberado", "incentivos")


def _secreto():
    v = os.getenv("PAYMENT_WEBHOOK_SECRET", "").strip()
    if len(v) < 16:
        raise RuntimeError("Falta PAYMENT_WEBHOOK_SECRET (minimo 16 caracteres). El receptor no arranca sin firma.")
    return v


def _ahora():
    return datetime.now(timezone.utc)


class PaymentEvent(Base):
    __tablename__ = "payment_events_v2"
    event_id = Column(String, primary_key=True, index=True)
    provider = Column(String, nullable=False)
    ledger_tx_id = Column(String, nullable=True)
    order_id = Column(String, nullable=True)
    provider_payment_id = Column(String, nullable=True)
    status = Column(String, default="RECEIVED")        # RECEIVED / PROCESSED / FAILED / REJECTED
    amount_cents = Column(Integer, nullable=True)
    currency = Column(String, nullable=True)
    meta_json = Column(JSON, nullable=True)
    steps_json = Column(JSON, nullable=True)           # pasos ya completados
    error = Column(String, nullable=True)
    received_at = Column(DateTime, default=_ahora)


app = FastAPI(title="Payments + Reconciliation (pp_modulo_7) v2")


@app.on_event("startup")
def _arranque():
    _secreto()                                  # falla en voz alta si no hay secreto
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    Base.metadata.create_all(bind=engine)


# -------------------------
# Utilidades
# -------------------------
def a_centavos(x) -> int:
    d = Decimal(str(x)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if d <= 0:
        raise ValueError("monto debe ser positivo")
    return int(d * 100)


def firma_valida(body: bytes, timestamp: Optional[str], signature: Optional[str]) -> bool:
    if not timestamp or not signature:
        return False
    try:
        ts = int(timestamp)
    except ValueError:
        return False
    if abs(time.time() - ts) > VENTANA_S:
        return False
    mac = hmac.new(_secreto().encode(), timestamp.encode() + b"." + body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(mac.encode(), signature.strip().lower().encode())


def marcar_ledger_pagado(ledger_tx_id: str, monto_c: int) -> bool:
    """True si paso de pendiente a pagado ahora; False si ya estaba pagado.
    Lanza RuntimeError si no existe o el monto no coincide."""
    s = SessionLocal()
    try:
        tx = s.query(FinancialLedger).filter_by(id_transaccion=ledger_tx_id).first()
        if not tx:
            raise RuntimeError("la transaccion del libro mayor no existe")
        if a_centavos(tx.monto) != monto_c:
            raise RuntimeError("el monto cobrado no coincide con el del libro mayor")
        # UPDATE condicional: solo uno de dos eventos simultaneos gana la transicion
        n = (s.query(FinancialLedger)
             .filter(FinancialLedger.id_transaccion == ledger_tx_id,
                     FinancialLedger.estado_pago == False)  # noqa: E712
             .update({"estado_pago": True}, synchronize_session=False))
        s.commit()
        return n == 1
    finally:
        s.close()


def _guardar(event_id, **campos):
    s = SessionLocal()
    try:
        ev = s.query(PaymentEvent).filter_by(event_id=event_id).first()
        for k, v in campos.items():
            setattr(ev, k, v)
        s.commit()
    finally:
        s.close()


def _cargar(event_id):
    s = SessionLocal()
    try:
        ev = s.query(PaymentEvent).filter_by(event_id=event_id).first()
        if not ev:
            return None
        return {"event_id": ev.event_id, "status": ev.status, "ledger_tx_id": ev.ledger_tx_id,
                "order_id": ev.order_id, "amount_cents": ev.amount_cents, "currency": ev.currency,
                "meta": ev.meta_json or {}, "steps": ev.steps_json or {}, "error": ev.error}
    finally:
        s.close()


def post_payment_pipeline(event_id: str) -> Dict[str, Any]:
    """Ejecuta los pasos pendientes del evento. Cada paso queda anotado; si falla uno,
    el evento queda FAILED y un reintento continua desde donde quedo."""
    ev = _cargar(event_id)
    if not ev:
        return {"ok": False, "error": "evento no existe"}
    if ev["status"] == "PROCESSED":
        return {"ok": True, "idempotent": True}
    meta, steps = ev["meta"], dict(ev["steps"])
    ledger_tx_id = ev["ledger_tx_id"]
    try:
        if not ledger_tx_id:
            raise RuntimeError("el evento no trae ledger_tx_id")

        if not steps.get("ledger_pagado"):
            cambio = marcar_ledger_pagado(ledger_tx_id, ev["amount_cents"])
            steps["ledger_pagado"] = True
            steps["primer_pago"] = bool(cambio)       # False = ya estaba pagado antes
            _guardar(event_id, steps_json=dict(steps))

        if ev["order_id"] and not steps.get("tokens"):
            order_credit_tokens_after_fiat_paid(ev["order_id"], fiat_paid=True)
            steps["tokens"] = True
            _guardar(event_id, steps_json=dict(steps))

        id_cliente, id_proyecto, run_id = meta.get("id_cliente"), meta.get("id_proyecto"), meta.get("run_id")
        if id_cliente and id_proyecto and run_id and not steps.get("liberado"):
            res = liberar_si_pagado(id_cliente, id_proyecto, run_id, ledger_tx_id)
            if not res.get("ok"):
                raise RuntimeError(f"no se pudo liberar: {res.get('error')}")
            steps["liberado"] = True
            _guardar(event_id, steps_json=dict(steps))

        # Incentivos: solo en la primera transicion a pagado, sobre el monto del libro mayor.
        if id_cliente and steps.get("primer_pago") and not steps.get("incentivos"):
            base = float(Decimal(ev["amount_cents"]) / 100)
            mlm_record_event(id_cliente, "ORDER_PAID", base, {"event_id": event_id, "ledger_tx_id": ledger_tx_id})
            mlm_payout(id_cliente, base_amount=base, percentages=MLM_PCTS)
            steps["incentivos"] = True
            _guardar(event_id, steps_json=dict(steps))

        _guardar(event_id, status="PROCESSED", error=None, steps_json=dict(steps))
        return {"ok": True, "steps": steps}
    except Exception as e:  # noqa: BLE001
        _guardar(event_id, status="FAILED", error=f"{type(e).__name__}: {e}"[:500], steps_json=dict(steps))
        return {"ok": False, "error": str(e), "steps": steps}


# -------------------------
# Endpoints
# -------------------------
@app.get("/health")
def health():
    return {"ok": True, "proveedores": sorted(PROVEEDORES), "niveles_incentivo": len(MLM_PCTS)}


@app.get("/events/{event_id}")
def estado_evento(event_id: str):
    ev = _cargar(event_id)
    if not ev:
        raise HTTPException(404, "evento no existe")
    return {k: ev[k] for k in ("event_id", "status", "steps", "error", "amount_cents", "currency")}


@app.post("/events/{event_id}/reintentar")
def reintentar(event_id: str, background: BackgroundTasks):
    ev = _cargar(event_id)
    if not ev:
        raise HTTPException(404, "evento no existe")
    if ev["status"] != "FAILED":
        raise HTTPException(409, f"solo se reintentan eventos FAILED (estado {ev['status']})")
    background.add_task(post_payment_pipeline, event_id)
    return {"ok": True, "reintentando": event_id}


@app.post("/webhook/{provider}")
async def webhook(provider: str, request: Request, background: BackgroundTasks,
                  x_signature: Optional[str] = Header(default=None),
                  x_timestamp: Optional[str] = Header(default=None)):
    if provider not in PROVEEDORES:
        raise HTTPException(404, "proveedor no habilitado")
    body = await request.body()
    if not firma_valida(body, x_timestamp, x_signature):
        raise HTTPException(401, "firma invalida o vencida")
    try:
        payload = json.loads(body.decode("utf-8"))
    except Exception:
        raise HTTPException(400, "cuerpo no es JSON")

    event_id = payload.get("event_id") or payload.get("id")
    if not event_id:
        raise HTTPException(400, "falta event_id")
    if payload.get("status") != "paid":
        return {"ok": True, "ignorado": "solo se procesan eventos con status=paid", "event_id": event_id}
    try:
        monto_c = a_centavos(payload.get("amount"))
    except Exception:
        raise HTTPException(400, "amount invalido")
    meta = payload.get("meta") or {}
    if not meta.get("ledger_tx_id"):
        raise HTTPException(400, "meta.ledger_tx_id es obligatorio")

    s = SessionLocal()
    try:
        if s.query(PaymentEvent).filter_by(event_id=event_id).first():
            return {"ok": True, "idempotent": True, "event_id": event_id}
        s.add(PaymentEvent(
            event_id=event_id, provider=provider, ledger_tx_id=meta.get("ledger_tx_id"),
            order_id=meta.get("order_id"), provider_payment_id=payload.get("payment_id"),
            status="RECEIVED", amount_cents=monto_c, currency=(payload.get("currency") or "").upper(),
            meta_json=meta, steps_json={}))
        try:
            s.commit()
        except IntegrityError:           # llegaron dos copias a la vez
            s.rollback()
            return {"ok": True, "idempotent": True, "event_id": event_id}
    finally:
        s.close()

    background.add_task(post_payment_pipeline, event_id)
    return {"ok": True, "event_id": event_id, "estado": "RECEIVED"}
