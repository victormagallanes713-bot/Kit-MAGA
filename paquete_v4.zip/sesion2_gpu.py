#!/usr/bin/env python3
"""
Sesion 2 con GPU: caras de medio cuerpo con luz suave + prueba de movimiento corporal (InfiniteTalk).

  caras      : retratos INVENTADOS de adultos, de la cintura hacia arriba y con las manos a la vista
               (sin manos visibles el modelo no puede gesticular), luz suave sin contraluz.
               4 candidatas para av01-av03 y 1 para el resto (CAND_TODAS=4 para 4 en todos).
  movimiento : InfiniteTalk con la candidata 1 de av01 y av03 y el audio ya generado en la sesion 1.
               Registra cuanto tarda cada clip: es el dato que falta para decidir.
  resumen    : nada se da por bueno sin comprobar que el archivo existe y dura algo.

Uso:  python3 sesion2_gpu.py [--fases caras,movimiento] [--forzar]
"""
import os
import sys
import json
import time
import argparse
import subprocess
from pathlib import Path

BASE = Path(os.getenv("MOTORES_BASE", "/workspace/projects/sistema_contenido_viral"))
sys.path.insert(0, str(BASE))
import sesion1_gpu as S1  # noqa: E402  (reutiliza los avatares, las rutas y la comprobacion de duracion)

SALIDA = Path(os.getenv("SESION2_DIR", "/workspace/avatares/sesion2"))
SESION1 = S1.SALIDA
FLUX_DIR = S1.FLUX_DIR
LOG = SALIDA / "registro.json"
RUN_IT = Path(os.getenv("RUN_INFINITETALK", str(BASE / "run_infinitetalk.sh")))
CAND_TODAS = int(os.getenv("CAND_TODAS", "0"))
CAND_POR_DEFECTO = {"av01": 4, "av02": 4, "av03": 4}
PRUEBA_MOVIMIENTO = [("av01", "es"), ("av03", "es")]


def candidatas(id_):
    return CAND_TODAS or CAND_POR_DEFECTO.get(id_, 1)


def cargar_log():
    return json.loads(LOG.read_text()) if LOG.exists() else {"pasos": {}}


def anotar(reg, clave, estado, detalle="", archivo=None):
    reg["pasos"][clave] = {"estado": estado, "detalle": detalle, "archivo": str(archivo) if archivo else None, "ts": S1.ahora()}
    LOG.write_text(json.dumps(reg, indent=2, ensure_ascii=False))
    print(f"[{estado:6}] {clave} {detalle}", flush=True)


def ya_ok(reg, clave, archivo, forzar):
    p = reg["pasos"].get(clave)
    return (not forzar) and p and p["estado"] == "OK" and Path(archivo).exists() and Path(archivo).stat().st_size > 0


def prompt_cara(desc, region):
    return (f"Medium shot photograph of a {desc}, {region} appearance, waist-up, arms relaxed with both hands "
            f"visible in front of the body, looking at the camera, soft diffused studio light, even natural skin "
            f"tones, no backlight, no direct sun, plain neutral background, photorealistic, sharp focus")


def fase_caras(reg, forzar):
    trabajo = []
    for id_, area, region, desc, seed in S1.AVATARES:
        for k in range(1, candidatas(id_) + 1):
            if not ya_ok(reg, f"cara_{id_}_c{k}", SALIDA / f"{id_}_c{k}.png", forzar):
                trabajo.append((id_, area, region, desc, seed + 17 * k, k))
    if not trabajo:
        print("caras: todas listas"); return
    try:
        import torch
        from diffusers import FluxPipeline
        pipe = FluxPipeline.from_pretrained(str(FLUX_DIR), torch_dtype=torch.bfloat16)
        vram = torch.cuda.get_device_properties(0).total_memory / 2**30
        pipe.to("cuda") if vram >= 40 else pipe.enable_model_cpu_offload()
    except Exception as e:  # noqa: BLE001
        for id_, *_r, k in trabajo:
            anotar(reg, f"cara_{id_}_c{k}", "FALLO", f"no se pudo cargar FLUX: {type(e).__name__}: {str(e)[:160]}")
        return
    for id_, area, region, desc, seed, k in trabajo:
        archivo = SALIDA / f"{id_}_c{k}.png"
        prompt = prompt_cara(desc, region)
        try:
            g = torch.Generator("cuda").manual_seed(seed)
            img = pipe(prompt, num_inference_steps=4, guidance_scale=0.0, height=1024, width=768, generator=g).images[0]
            img.save(archivo)
            ficha = {"id": id_, "candidata": k, "area": area, "region_aspecto": region, "seed": seed, "prompt": prompt,
                     "motor": "FLUX.1-schnell", "persona_real": False, "etiqueta": "personaje creado con IA", "adulto": True}
            (SALIDA / f"{id_}_c{k}.json").write_text(json.dumps(ficha, indent=2, ensure_ascii=False))
            anotar(reg, f"cara_{id_}_c{k}", "OK", area, archivo)
        except Exception as e:  # noqa: BLE001
            anotar(reg, f"cara_{id_}_c{k}", "FALLO", f"{type(e).__name__}: {str(e)[:160]}")
    del pipe
    torch.cuda.empty_cache()


def fase_movimiento(reg, forzar):
    if not RUN_IT.exists():
        for id_, lang in PRUEBA_MOVIMIENTO:
            anotar(reg, f"mov_{id_}_{lang}", "FALLO", f"falta {RUN_IT}")
        return
    for id_, lang in PRUEBA_MOVIMIENTO:
        cara = SALIDA / f"{id_}_c1.png"
        audio = SESION1 / f"{id_}_{lang}.wav"
        archivo = SALIDA / f"mov_{id_}_{lang}.mp4"
        clave = f"mov_{id_}_{lang}"
        if ya_ok(reg, clave, archivo, forzar):
            continue
        if not cara.exists() or not audio.exists():
            anotar(reg, clave, "OMITIDO", "falta la cara de medio cuerpo o el audio de la sesion 1")
            continue
        t0 = time.time()
        r = subprocess.run(["bash", str(RUN_IT), str(cara), str(audio), str(archivo)], capture_output=True, text=True)
        seg = time.time() - t0
        d_audio = S1.duracion(audio)
        if r.returncode == 0 and archivo.exists() and S1.duracion(archivo) > 1.0:
            anotar(reg, clave, "OK", f"video {S1.duracion(archivo):.1f}s (audio {d_audio:.1f}s), calculo {seg/60:.1f} min", archivo)
        else:
            cola = (r.stderr or r.stdout or "")[-300:].replace("\n", " | ")
            anotar(reg, clave, "FALLO", f"codigo {r.returncode}, {seg/60:.1f} min: {cola}")


def resumen(reg):
    c = {"OK": 0, "FALLO": 0, "OMITIDO": 0}
    for p in reg["pasos"].values():
        c[p["estado"]] = c.get(p["estado"], 0) + 1
    print(f"\nRESUMEN  OK {c['OK']} | FALLO {c['FALLO']} | OMITIDO {c['OMITIDO']}   (detalle: {LOG})")
    for k, p in reg["pasos"].items():
        if p["estado"] != "OK":
            print(f"  {p['estado']}: {k} -> {p['detalle']}")
    return c["FALLO"] == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fases", default="caras,movimiento")
    ap.add_argument("--forzar", action="store_true")
    a = ap.parse_args()
    SALIDA.mkdir(parents=True, exist_ok=True)
    reg = cargar_log()
    fases = [f.strip() for f in a.fases.split(",")]
    if "caras" in fases:
        fase_caras(reg, a.forzar)
    if "movimiento" in fases:
        fase_movimiento(reg, a.forzar)
    sys.exit(0 if resumen(reg) else 1)


if __name__ == "__main__":
    main()
