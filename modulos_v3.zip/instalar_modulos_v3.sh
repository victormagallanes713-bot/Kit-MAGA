#!/usr/bin/env bash
# Instala motores v2 (modulos 10, 15, 17, 18), scripts de LatentSync y la sesion 1.
set -euo pipefail
BASE="${BASE:-/workspace/projects/sistema_contenido_viral}"
AQUI="$(cd "$(dirname "$0")" && pwd)"
ARCH="pp_modulo_10_produccion.py pp_modulo_15_stack_ia.py pp_modulo_17_motores.py pp_modulo_18_video.py run_latentsync.sh instalar_latentsync.sh sesion1_gpu.py lote_gpu.sh"
cd "$BASE"
R="$BASE/_respaldo_v3_$(date +%Y%m%d_%H%M%S)"; mkdir -p "$R"
for f in $ARCH; do
  [ -f "$f" ] && cp -p "$f" "$R/" && echo "respaldo: $f"
  cp "$AQUI/$f" "$f"
done
chmod +x run_latentsync.sh instalar_latentsync.sh lote_gpu.sh
python3 -m py_compile pp_modulo_10_produccion.py pp_modulo_15_stack_ia.py pp_modulo_17_motores.py pp_modulo_18_video.py sesion1_gpu.py && echo "sintaxis OK"
bash -n run_latentsync.sh && bash -n instalar_latentsync.sh && bash -n lote_gpu.sh && echo "scripts OK"
echo "== pruebas =="; MODULOS_DIR="$BASE" python3 "$AQUI/pruebas/test_motores.py" | tail -3
echo "Respaldo en: $R"
