"""
Modulo 21 - Contrato electronico + puerta de ingesta.  v2

Cambios respecto a v1:
  - Ya NO se obliga a autorizar la clonacion de voz al inscribirse. La
    autorizacion de clonacion es SEPARADA, OPCIONAL y se da voz por voz en el
    modulo 20 (registrar_voz). El contrato de adhesion no la contiene.
  - El documento de identidad se guarda como HMAC completo (no hash simple ni truncado).
  - El secreto HMAC es obligatorio.
  - La API escucha solo en 127.0.0.1.
  - Si el contrato se carga desde un archivo externo, el estado lo indica y avisa
    si ese texto aun contiene una clausula de clonacion obligatoria.

IMPORTANTE: el texto embebido es un BORRADOR tecnico. Antes de usarlo con
usuarios reales debe revisarlo un abogado.
"""
import os
import json
import sqlite3
import hashlib
from datetime import datetime, timezone
from pathlib import Path

import comun_seguridad as seg

DB_PATH = os.getenv("CONTRATO_DB", "/workspace/contratos_v2.db")
CONTRATO_VERSION = "2.1"

CONTRATO_PATH = os.getenv(
    "CONTRATO_PATH",
    "/workspace/projects/sistema_contenido_viral/CONTRATO_ADHESION_GLOBAL.md")

_CONTRATO_EMBEBIDO = """CONTRATO ELECTRONICO DE ADHESION - PLATAFORMA DE MEDIOS E IA  (BORRADOR)

1. IDENTIFICACION DEL ADHERENTE. El usuario declara su nombre, documento y
   correo, y su rol (artista, cantante, locutor, creador de contenido).

2. VOZ Y CLONACION (SEPARADA Y OPCIONAL). Inscribirse NO implica autorizar la
   clonacion de ninguna voz. Cada voz se autoriza por separado, de forma
   expresa, para ese titular y ese uso, y puede REVOCARSE y BORRARSE en
   cualquier momento.

3. RESPONSABILIDAD DEL DEPOSITANTE. Todo material que el usuario deposite es
   de su responsabilidad frente a terceros. El usuario garantiza la
   legitimidad y los derechos sobre lo que entrega.

4. VOCES DE TERCEROS. Si el usuario deposita la voz de un tercero, esta sera
   auditada contra el repositorio de la plataforma. Si resulta muy similar a
   una voz registrada (segun el umbral vigente de similitud), sera RECHAZADA
   y se indicara a quien corresponde. Esa auditoria es una ayuda tecnica, no
   una garantia de identidad.

5. LIMITE DE RESPONSABILIDAD DE LA EMPRESA. La empresa valida lo que consta en
   su base de datos. La empresa responde por las producciones y voces que ella
   misma genere. Todo el contenido generado se identifica como creado con IA.

6. RETIRO A REQUERIMIENTO. Cualquier persona puede reclamar un elemento que
   vulnere sus derechos o la norma; la plataforma lo revisa y, si procede, lo
   retira.

7. ACEPTACION. La firma electronica de este contrato equivale a firma valida
   conforme al procedimiento de la plataforma.
"""


def _cargar_contrato():
    try:
        with open(CONTRATO_PATH, encoding="utf-8") as f:
            t = f.read()
        if len(t.strip()) > 200:
            return t, "archivo"
    except Exception:
        pass
    return _CONTRATO_EMBEBIDO, "embebido"


CONTRATO_TEXTO, CONTRATO_ORIGEN = _cargar_contrato()
CONTRATO_HASH = hashlib.sha256(CONTRATO_TEXTO.encode()).hexdigest()


def avisos_contrato():
    """Alertas sobre el texto cargado (no bloquean, pero se muestran en /contrato/estado)."""
    out = []
    bajo = CONTRATO_TEXTO.lower()
    if CONTRATO_ORIGEN == "archivo" and (
            "autoriza expresamente la clonacion" in bajo
            or "autoriza expresamente la clonación" in bajo
            or "todo usuario" in bajo and "autoriza" in bajo and "clon" in bajo):
        out.append("El archivo externo parece exigir autorizar la clonacion al inscribirse; "
                   "contradice el consentimiento voz por voz. Revisalo con un abogado.")
    if "borrador" in bajo:
        out.append("El texto esta marcado como BORRADOR.")
    return out


_DESTACADAS = [
    "licencia", "revocable", "limitación", "limitacion", "no responde",
    "responsabilidad", "arbitraje", "comisión tecnológica", "comision tecnologica",
    "no custodia", "retracto", "renuncia",
]


def clausulas_destacadas():
    out = []
    for ln in CONTRATO_TEXTO.splitlines():
        low = ln.lower()
        if len(ln.strip()) > 25 and any(d in low for d in _DESTACADAS):
            out.append(ln.strip())
    return out


ROLES = ("artista", "cantante", "locutor", "influencer", "creador", "otro")


def _now():
    return datetime.now(timezone.utc).isoformat()


def _db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("""CREATE TABLE IF NOT EXISTS firmantes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL, doc_hash TEXT NOT NULL, email TEXT,
        rol TEXT NOT NULL, ip TEXT, ts TEXT NOT NULL, contrato_version TEXT NOT NULL,
        contrato_hash TEXT NOT NULL, firma TEXT NOT NULL, estado TEXT NOT NULL,
        motivo TEXT)""")
    con.execute("""CREATE TABLE IF NOT EXISTS depositos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, firmante_id INTEGER,
        asset TEXT NOT NULL, tipo TEXT, es_tercero INTEGER NOT NULL,
        voz_audit TEXT, resultado TEXT NOT NULL, motivo TEXT, ts TEXT NOT NULL)""")
    con.execute("""CREATE TABLE IF NOT EXISTS eventos (
        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, accion TEXT,
        detalle TEXT, resultado TEXT)""")
    con.commit()
    return con


def _evento(con, accion, detalle, resultado):
    con.execute("INSERT INTO eventos(ts,accion,detalle,resultado) VALUES(?,?,?,?)",
                (_now(), accion, detalle, resultado))
    con.commit()


def firmar_contrato(nombre, doc, rol, email="", ip=""):
    """Firma el contrato de adhesion. No autoriza ninguna clonacion de voz."""
    if not nombre or not doc:
        return {"estado": "RECHAZADO", "motivo": "faltan nombre o documento"}
    if rol not in ROLES:
        return {"estado": "RECHAZADO", "motivo": f"rol invalido; use uno de {ROLES}"}
    dh = seg.hash_documento(doc)               # falla si no hay secreto
    ts = _now()
    firma = seg.firma(f"{nombre}|{dh}|{ts}|{CONTRATO_HASH}")
    con = _db()
    cur = con.execute("INSERT INTO firmantes(nombre,doc_hash,email,rol,ip,ts,contrato_version,"
                      "contrato_hash,firma,estado,motivo) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                      (nombre, dh, email, rol, ip, ts, CONTRATO_VERSION,
                       CONTRATO_HASH, firma, "ACTIVO", ""))
    fid = cur.lastrowid
    con.commit()
    _evento(con, "FIRMA_CONTRATO", f"firmante={fid} rol={rol}", "ACTIVO")
    con.close()
    return {"estado": "ACTIVO", "firmante_id": fid, "contrato_version": CONTRATO_VERSION,
            "firma": firma, "ts": ts,
            "nota": "La clonacion de tu voz NO esta autorizada por este contrato; se autoriza aparte, voz por voz."}


def firmante_activo(doc):
    con = _db()
    r = con.execute("SELECT * FROM firmantes WHERE doc_hash=? AND estado='ACTIVO' "
                    "ORDER BY id DESC LIMIT 1", (seg.hash_documento(doc),)).fetchone()
    con.close()
    return dict(r) if r else None


def depositar(doc, asset, es_tercero=False, tipo=None, wav_voz=None):
    f = firmante_activo(doc)
    if not f:
        return {"estado": "RECHAZADO", "motivo": "no hay contrato electronico firmado; firme antes de depositar"}
    if not Path(asset).exists():
        return {"estado": "ERROR", "motivo": f"no existe el archivo: {asset}"}
    voz = None
    if es_tercero:
        if not wav_voz:
            return {"estado": "RECHAZADO", "motivo": "voz de tercero: falta el audio para auditar"}
        import pp_modulo_20_consentimiento as M20
        voz = M20.verificar_voz(wav_voz)
        if voz.get("estado") == "RECHAZADO":
            con = _db()
            con.execute("INSERT INTO depositos(firmante_id,asset,tipo,es_tercero,"
                        "voz_audit,resultado,motivo,ts) VALUES(?,?,?,?,?,?,?,?)",
                        (f["id"], asset, tipo, 1, json.dumps(voz), "RECHAZADO",
                         "coincide con una voz registrada", _now()))
            con.commit()
            _evento(con, "DEPOSITO_TERCERO", f"firmante={f['id']} -> {asset}", "RECHAZADO")
            con.close()
            quien = voz.get("coincide_con") or "un titular registrado"
            return {"estado": "RECHAZADO", "motivo": f"esa voz corresponde a {quien}; no la podemos aceptar"}
    con = _db()
    cur = con.execute("INSERT INTO depositos(firmante_id,asset,tipo,es_tercero,voz_audit,"
                      "resultado,motivo,ts) VALUES(?,?,?,?,?,?,?,?)",
                      (f["id"], asset, tipo, 1 if es_tercero else 0,
                       json.dumps(voz) if voz else None, "ACEPTADO", "", _now()))
    dep_id = cur.lastrowid
    con.commit()
    _evento(con, "DEPOSITO", f"firmante={f['id']} -> {asset} tercero={bool(es_tercero)}", "ACEPTADO")
    con.close()
    return {"estado": "ACEPTADO", "deposito_id": dep_id, "responsable": f["nombre"], "voz_audit": voz}


def retirar(deposito_id, motivo="reclamacion de tercero"):
    con = _db()
    r = con.execute("SELECT * FROM depositos WHERE id=?", (deposito_id,)).fetchone()
    if not r:
        con.close()
        return {"estado": "ERROR", "motivo": "deposito no existe"}
    con.execute("UPDATE depositos SET resultado='RETIRADO', motivo=? WHERE id=?",
                (motivo, deposito_id))
    con.commit()
    _evento(con, "RETIRO", f"deposito {deposito_id}: {motivo}", "RETIRADO")
    con.close()
    return {"estado": "RETIRADO", "deposito_id": deposito_id, "motivo": motivo}


def listar_firmantes():
    con = _db()
    out = [dict(r) for r in con.execute(
        "SELECT id,nombre,email,rol,ts,estado FROM firmantes ORDER BY id DESC")]
    con.close()
    return out


def listar_depositos():
    con = _db()
    out = [dict(r) for r in con.execute("SELECT * FROM depositos ORDER BY id DESC")]
    con.close()
    return out


def eventos(limite=50):
    con = _db()
    out = [dict(r) for r in con.execute("SELECT * FROM eventos ORDER BY id DESC LIMIT ?", (limite,))]
    con.close()
    return out


def crear_app():
    from fastapi import FastAPI, Form
    from fastapi.responses import JSONResponse, PlainTextResponse
    seg.secreto()   # detiene el arranque si el secreto falta o es debil
    app = FastAPI(title="M21 Contrato Electronico + Ingesta")

    @app.get("/contrato/texto", response_class=PlainTextResponse)
    def texto():
        return CONTRATO_TEXTO

    @app.get("/contrato/destacadas")
    def destacadas():
        return {"version": CONTRATO_VERSION, "hash": CONTRATO_HASH,
                "clausulas_que_limitan_derechos": clausulas_destacadas()}

    @app.get("/contrato/estado")
    def estado():
        return {"version": CONTRATO_VERSION, "hash": CONTRATO_HASH, "origen": CONTRATO_ORIGEN,
                "avisos": avisos_contrato(), "firmantes": len(listar_firmantes()),
                "depositos": len(listar_depositos())}

    @app.get("/contrato/firmantes")
    def firmantes():
        return listar_firmantes()

    @app.get("/contrato/depositos")
    def depositos():
        return listar_depositos()

    @app.get("/contrato/eventos")
    def _eventos(limite: int = 50):
        return eventos(limite)

    @app.post("/contrato/firmar")
    def firmar(nombre: str = Form(...), doc: str = Form(...), rol: str = Form(...),
               email: str = Form(""), ip: str = Form("")):
        return JSONResponse(firmar_contrato(nombre, doc, rol, email, ip))

    @app.post("/contrato/depositar")
    def _depositar(doc: str = Form(...), asset: str = Form(...),
                   es_tercero: bool = Form(False), tipo: str = Form(None), wav_voz: str = Form(None)):
        return JSONResponse(depositar(doc, asset, es_tercero, tipo, wav_voz))

    @app.post("/contrato/retirar")
    def _retirar(deposito_id: int = Form(...), motivo: str = Form("reclamacion de tercero")):
        return JSONResponse(retirar(deposito_id, motivo))

    return app


if __name__ == "__main__" and os.getenv("M21_API") == "1":
    import uvicorn
    uvicorn.run(crear_app(), host=seg.HOST_API, port=int(os.getenv("M21_PORT", "8091")))
