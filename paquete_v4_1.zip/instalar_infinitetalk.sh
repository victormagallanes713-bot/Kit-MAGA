#!/usr/bin/env bash
# InfiniteTalk (Apache 2.0): cabeza, cuerpo y expresiones guiados por el audio.
#   bash instalar_infinitetalk.sh plan       -> NO descarga nada: muestra espacio libre y tamano de los pesos
#   bash instalar_infinitetalk.sh instalar   -> codigo + entorno Python 3.10 (no necesita GPU)
#   bash instalar_infinitetalk.sh pesos      -> descarga los pesos al volumen (grandes; ejecutar tras "plan")
# Entorno propio (/workspace/venv_infinitetalk): no toca venv_ia ni venv_latentsync.
set -uo pipefail
IT_DIR="${INFINITETALK_DIR:-/workspace/InfiniteTalk}"
VENV="${INFINITETALK_VENV:-/workspace/venv_infinitetalk}"
W="${INFINITETALK_WEIGHTS:-/workspace/models_repository/infinitetalk}"
HFPY="${HFPY:-/workspace/venv_ia/bin/python}"
export HF_HOME="${HF_HOME:-/workspace/.cache/huggingface}"
MODO="${1:-plan}"

REPO_BASE="Wan-AI/Wan2.1-I2V-14B-480P"
REPO_IT="MeiGen-AI/InfiniteTalk"
REPO_W2V="TencentGameMate/chinese-wav2vec2-base"
# Solo se baja lo que usamos: una persona + version fp8 + T5 fp8 (cabe en 24 GB con descarga a CPU).
# Se descartan las variantes de varias personas, int8, LoRA y ComfyUI (mas de 120 GB que no aportan a este caso).
PAT_IT="single/infinitetalk.safetensors quant_models/infinitetalk_single_fp8.safetensors quant_models/t5_fp8.safetensors"
export PAT_IT

hf_py() { "$HFPY" - "$@"; }

if [ "$MODO" = "plan" ]; then
  echo "== espacio en el volumen =="; df -h /workspace | tail -n 1
  hf_py <<'EOF'
import sys, fnmatch
from huggingface_hub import HfApi
api = HfApi()
def total(repo, pats=None, rev=None):
    info = api.model_info(repo, files_metadata=True, revision=rev)
    t = 0; grandes = []
    for s in info.siblings:
        if pats and not any(fnmatch.fnmatch(s.rfilename, p) for p in pats):
            continue
        t += (s.size or 0)
        if (s.size or 0) > 1e9: grandes.append((s.rfilename, s.size))
    return t, grandes
import os
PAT_IT = os.environ["PAT_IT"].split()
plan = [("Wan-AI/Wan2.1-I2V-14B-480P", None), ("MeiGen-AI/InfiniteTalk", PAT_IT),
        ("TencentGameMate/chinese-wav2vec2-base", None)]
suma = 0
for repo, pats in plan:
    try:
        t, g = total(repo, pats)
    except Exception as e:
        print(f"  {repo}: NO SE PUDO CONSULTAR ({type(e).__name__}: {str(e)[:120]})"); continue
    suma += t
    print(f"  {repo}: {t/1e9:.1f} GB" + (f"  (archivos grandes: {len(g)})" if g else ""))
print(f"== TOTAL a descargar: {suma/1e9:.1f} GB ==")
EOF
  echo "Si el total cabe con holgura en el espacio libre, sigue con:  bash instalar_infinitetalk.sh instalar"
  exit 0
fi

if [ "$MODO" = "instalar" ]; then
  command -v git >/dev/null || { echo "falta git"; exit 1; }
  if [ ! -f "$IT_DIR/generate_infinitetalk.py" ]; then
    git clone --depth 1 https://github.com/MeiGen-AI/InfiniteTalk "$IT_DIR" || { echo "FALLO git clone"; exit 1; }
  fi
  command -v uv >/dev/null || pip install -q uv 2>/dev/null || pip install -q --break-system-packages uv || { echo "FALLO instalando uv"; exit 1; }
  if [ ! -x "$VENV/bin/python" ] || ! "$VENV/bin/python" -c "import sys;sys.exit(0 if sys.version_info[:2]==(3,10) else 1)"; then
    rm -rf "$VENV"; uv venv --python 3.10 "$VENV" || { echo "FALLO creando el entorno Python 3.10"; exit 1; }
  fi
  PY="$VENV/bin/python"
  UVP=(uv pip install --python "$PY")
  echo "== torch 2.4.1 (cu121) y xformers =="
  "${UVP[@]}" torch==2.4.1 torchvision==0.19.1 torchaudio==2.4.1 --index-url https://download.pytorch.org/whl/cu121 || { echo "FALLO torch"; exit 1; }
  "${UVP[@]}" xformers==0.0.28 --index-url https://download.pytorch.org/whl/cu121 || { echo "FALLO xformers"; exit 1; }
  echo "== dependencias de compilacion =="
  "${UVP[@]}" ninja psutil packaging wheel "misaki[en]" || { echo "FALLO dependencias base"; exit 1; }
  echo "== flash-attn 2.7.4.post1 (primero la version ya compilada; si no existe, se compila y tarda mucho) =="
  WHL="https://github.com/Dao-AILab/flash-attention/releases/download/v2.7.4.post1/flash_attn-2.7.4.post1+cu12torch2.4cxx11abiFALSE-cp310-cp310-linux_x86_64.whl"
  if ! "${UVP[@]}" "$WHL"; then
    echo "AVISO: no se pudo usar la version ya compilada; compilando (puede tardar 30-90 minutos)"
    "${UVP[@]}" --no-build-isolation flash_attn==2.7.4.post1 || { echo "FALLO flash-attn"; exit 1; }
  fi
  echo "== requirements del repositorio =="
  "${UVP[@]}" -r "$IT_DIR/requirements.txt" || { echo "FALLO requirements.txt"; exit 1; }
  "${UVP[@]}" librosa || { echo "FALLO librosa"; exit 1; }
  # El requirements no debe haber cambiado torch; se comprueba.
  "$PY" -c "import torch,xformers,librosa;print('torch',torch.__version__)" || { echo "FALLO la comprobacion de imports"; exit 1; }
  "$PY" -c "import flash_attn;print('flash_attn',flash_attn.__version__)" || echo "AVISO: flash_attn no importa (sin GPU a veces falla); se confirma en el pod con GPU"
  command -v ffmpeg >/dev/null || echo "AVISO: falta ffmpeg"
  echo "Listo. Siguiente: bash instalar_infinitetalk.sh pesos"
  exit 0
fi

if [ "$MODO" = "pesos" ]; then
  mkdir -p "$W"
  hf_py "$W" <<'EOF'
import sys, os
from huggingface_hub import snapshot_download, hf_hub_download
PAT_IT = os.environ["PAT_IT"].split()
W = sys.argv[1]
def paso(nombre, f):
    print(f"== {nombre} ==", flush=True)
    try:
        f(); print("   OK", flush=True)
    except Exception as e:
        print(f"   FALLO: {type(e).__name__}: {str(e)[:200]}", flush=True); sys.exit(1)
paso("Wan2.1-I2V-14B-480P (base)", lambda: snapshot_download("Wan-AI/Wan2.1-I2V-14B-480P", local_dir=f"{W}/Wan2.1-I2V-14B-480P"))
paso("InfiniteTalk (una persona + fp8 + T5 fp8)", lambda: snapshot_download("MeiGen-AI/InfiniteTalk", local_dir=f"{W}/InfiniteTalk", allow_patterns=PAT_IT))
paso("chinese-wav2vec2-base", lambda: snapshot_download("TencentGameMate/chinese-wav2vec2-base", local_dir=f"{W}/chinese-wav2vec2-base"))
# El README indica que model.safetensors sale de la revision refs/pr/1
paso("wav2vec2 model.safetensors (refs/pr/1)", lambda: hf_hub_download("TencentGameMate/chinese-wav2vec2-base", "model.safetensors", revision="refs/pr/1", local_dir=f"{W}/chinese-wav2vec2-base"))
EOF
  RC=$?
  [ $RC = 0 ] || { echo "FALLO la descarga de pesos"; exit $RC; }
  for f in "$W/InfiniteTalk/single/infinitetalk.safetensors" "$W/InfiniteTalk/quant_models/infinitetalk_single_fp8.safetensors" \
           "$W/InfiniteTalk/quant_models/t5_fp8.safetensors" "$W/chinese-wav2vec2-base/model.safetensors"; do
    [ -s "$f" ] && echo "  [OK]    $f" || echo "  [FALLO] falta $f"
  done
  du -sh "$W"
  exit 0
fi
echo "Uso: bash instalar_infinitetalk.sh plan | instalar | pesos"; exit 2
