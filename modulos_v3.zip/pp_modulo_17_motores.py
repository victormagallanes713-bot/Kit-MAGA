"""
Modulo 17 - Motores reales: transcripcion, clonacion de voz, mux.  v2

Cambios respecto a v1:
  - Transcripcion: faster-whisper large-v3 (CTranslate2, MIT) en lugar de la
    carpeta whisperx borrada.
  - Voz: Chatterbox Multilingual (MIT) en lugar de F5-TTS (pesos no comerciales).
  - La clonacion EXIGE una referencia de consentimiento; sin ella no clona.
    Si se indica el fingerprint de la voz (modulo 20), debe estar ACTIVA.
  - Idiomas con voz: se leen del motor real (SOPORTE_VOZ), no de una lista fija.
  - Nada se simula: si falta un paquete o un modelo, devuelve NO_DISPONIBLE con la causa.
"""
import os
import json
import shutil
import subprocess
import importlib.util
from pathlib import Path

BASE = Path(os.getenv("MOTORES_BASE", "/workspace/projects/sistema_contenido_viral"))
MODELS = Path(os.getenv("MODELS_REPO", "/workspace/models_repository"))
FW_DIR = Path(os.getenv("FASTER_WHISPER_DIR", str(MODELS / "faster-whisper-large-v3")))
CBX_DIR = Path(os.getenv("CHATTERBOX_DIR", str(MODELS / "chatterbox")))

# Segun la documentacion de Chatterbox Multilingual (revisar al actualizar el motor).
SOPORTE_VOZ = {"ar", "da", "de", "el", "en", "es", "fi", "fr", "he", "hi", "it", "ja", "ko", "ms",
               "nl", "no", "pl", "pt", "ru", "sv", "sw", "tr", "zh"}


def _hay(paquete):
    return importlib.util.find_spec(paquete) is not None


def _device():
    try:
        import torch
        return "cuda" if torch.cuda.is_available() else "cpu"
    except Exception:
        return "cpu"


def _liberar_gpu():
    try:
        import gc
        import torch
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except Exception:
        pass


# ------------------------------- TRANSCRIPCION ------------------------------
def transcribir(audio_path, idioma=None):
    """faster-whisper large-v3. Devuelve texto y segmentos con tiempos."""
    if not _hay("faster_whisper"):
        return {"motor": "faster-whisper", "estado": "NO_DISPONIBLE",
                "detalle": "falta el paquete: pip install faster-whisper"}
    if not (FW_DIR / "model.bin").exists():
        return {"motor": "faster-whisper", "estado": "NO_DISPONIBLE",
                "detalle": f"falta el modelo en {FW_DIR} (model.bin)"}
    from faster_whisper import WhisperModel
    dev = _device()
    modelo = WhisperModel(str(FW_DIR), device=dev, compute_type="float16" if dev == "cuda" else "int8")
    try:
        segs, info = modelo.transcribe(str(audio_path), language=idioma, vad_filter=True)
        trozos = [{"inicio": round(s.start, 2), "fin": round(s.end, 2), "texto": s.text.strip()} for s in segs]
    finally:
        del modelo
        _liberar_gpu()
    return {"motor": "faster-whisper-large-v3", "estado": "OK", "audio": str(audio_path),
            "idioma_detectado": info.language, "duracion_s": round(info.duration, 2),
            "texto": " ".join(t["texto"] for t in trozos).strip(), "segmentos": trozos}


# ------------------------------ CLONACION DE VOZ ----------------------------
def _cargar_chatterbox(dev):
    from chatterbox.mtl_tts import ChatterboxMultilingualTTS
    if CBX_DIR.exists() and hasattr(ChatterboxMultilingualTTS, "from_local"):
        return ChatterboxMultilingualTTS.from_local(str(CBX_DIR), dev)
    return ChatterboxMultilingualTTS.from_pretrained(device=dev)


def _trocear(texto, max_chars=280):
    out, cur = [], ""
    for frase in texto.replace("\n", " ").split(". "):
        frase = frase.strip()
        if not frase:
            continue
        if len(cur) + len(frase) + 2 > max_chars and cur:
            out.append(cur.strip())
            cur = ""
        cur += frase + ". "
    if cur.strip():
        out.append(cur.strip())
    return out or [texto]


def clonar_voz(texto, ref_audio, salida, idioma="es", consentimiento_ref=None, voz_fingerprint=None):
    """Chatterbox: clona el timbre de ref_audio. Exige consentimiento documentado."""
    if not consentimiento_ref or not str(consentimiento_ref).strip():
        return {"motor": "chatterbox", "estado": "RECHAZADO",
                "detalle": "falta consentimiento_ref: no se clona una voz sin consentimiento documentado"}
    if voz_fingerprint:
        try:
            import pp_modulo_20_consentimiento as M20
            if not M20.voz_activa(voz_fingerprint):
                return {"motor": "chatterbox", "estado": "RECHAZADO",
                        "detalle": "la voz no esta ACTIVA en el registro de consentimiento (revocada o inexistente)"}
        except Exception as e:  # noqa: BLE001
            return {"motor": "chatterbox", "estado": "ERROR",
                    "detalle": f"no se pudo consultar el modulo 20: {type(e).__name__}: {e}"}
    if idioma not in SOPORTE_VOZ:
        return {"motor": "chatterbox", "estado": "NO_SOPORTADO",
                "detalle": f"chatterbox no clona voz en '{idioma}'"}
    if not _hay("chatterbox"):
        return {"motor": "chatterbox", "estado": "NO_DISPONIBLE", "detalle": "falta el paquete chatterbox-tts"}
    if not Path(ref_audio).exists():
        return {"motor": "chatterbox", "estado": "ERROR", "detalle": f"no existe la referencia: {ref_audio}"}
    import torch
    import torchaudio as ta
    dev = _device()
    modelo = _cargar_chatterbox(dev)
    try:
        partes = [modelo.generate(t, language_id=idioma, audio_prompt_path=str(ref_audio)) for t in _trocear(texto)]
        Path(salida).parent.mkdir(parents=True, exist_ok=True)
        sr = modelo.sr
        ta.save(str(salida), torch.cat(partes, dim=-1), sr)
    finally:
        del modelo
        _liberar_gpu()
    return {"motor": "chatterbox", "estado": "OK", "salida": str(salida), "sr": sr,
            "idioma": idioma, "consentimiento_ref": consentimiento_ref}


def sintetizar_voz_base(texto, salida, idioma="es"):
    """Voz sintetica POR DEFECTO de Chatterbox (no clona a nadie, no requiere consentimiento).
    OJO: todos los avatares que la usen suenan igual; para voces distintas hace falta
    otra fuente (voz propia con consentimiento, locutor contratado o un motor con diseno de voz)."""
    if idioma not in SOPORTE_VOZ:
        return {"motor": "chatterbox", "estado": "NO_SOPORTADO", "detalle": f"sin voz en '{idioma}'"}
    if not _hay("chatterbox"):
        return {"motor": "chatterbox", "estado": "NO_DISPONIBLE", "detalle": "falta el paquete chatterbox-tts"}
    import torch
    import torchaudio as ta
    modelo = _cargar_chatterbox(_device())
    try:
        partes = [modelo.generate(t, language_id=idioma) for t in _trocear(texto)]
        Path(salida).parent.mkdir(parents=True, exist_ok=True)
        sr = modelo.sr
        ta.save(str(salida), torch.cat(partes, dim=-1), sr)
    finally:
        del modelo
        _liberar_gpu()
    return {"motor": "chatterbox", "estado": "OK", "salida": str(salida), "sr": sr, "idioma": idioma,
            "tipo": "voz_base_sintetica"}


def idiomas_soportados():
    return sorted(SOPORTE_VOZ)


# ----------------------------------- MUX ------------------------------------
def mux_video(visual, audio, salida):
    """Fusiona imagen/video + audio en un mp4 con ffmpeg."""
    if not shutil.which("ffmpeg"):
        return {"motor": "ffmpeg", "estado": "NO_DISPONIBLE", "detalle": "ffmpeg ausente"}
    Path(salida).parent.mkdir(parents=True, exist_ok=True)
    visual, audio = str(visual), str(audio)
    if Path(visual).suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
        cmd = ["ffmpeg", "-y", "-loop", "1", "-i", visual, "-i", audio, "-c:v", "libx264",
               "-tune", "stillimage", "-c:a", "aac", "-pix_fmt", "yuv420p", "-shortest", str(salida)]
    else:
        cmd = ["ffmpeg", "-y", "-stream_loop", "-1", "-i", visual, "-i", audio, "-map", "0:v:0", "-map", "1:a:0",
               "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(salida)]
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    return {"motor": "ffmpeg", "estado": "OK" if p.returncode == 0 else "ERROR", "salida": str(salida),
            "returncode": p.returncode, "stderr_tail": p.stderr[-300:] if p.returncode else ""}


def estado_motores():
    return {
        "transcripcion_faster_whisper": {"listo": _hay("faster_whisper") and (FW_DIR / "model.bin").exists(),
                                         "modelo": str(FW_DIR)},
        "voz_chatterbox": {"listo": _hay("chatterbox"), "modelo": str(CBX_DIR), "existe_modelo": CBX_DIR.exists(),
                           "idiomas": len(SOPORTE_VOZ)},
        "mux_ffmpeg": {"listo": bool(shutil.which("ffmpeg"))},
    }


if __name__ == "__main__":
    print(json.dumps(estado_motores(), indent=2, ensure_ascii=False))
