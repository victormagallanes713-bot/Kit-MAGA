# Motores v2 + sesion 1 (v3 del kit)
Contenido: modulos 10, 15, 17, 18 corregidos; run_latentsync.sh, instalar_latentsync.sh; sesion1_gpu.py; lote_gpu.sh.

- 17: faster-whisper (transcripcion), Chatterbox (voz; clonar exige consentimiento_ref), mux.
- 18: Flux + LatentSync (reemplaza Wav2Lip). Cara de persona real exige consentimiento_ref.
- 10 y 15: sin referencias a XTTS, F5, Fish, WhisperX, Wav2Lip ni modelos de codigo.
- lote_gpu.sh preparar  -> sin GPU: instala paquetes y LatentSync y revisa los modelos.
- lote_gpu.sh ejecutar  -> con GPU: 10 caras, 20 voces base (es/en) y 6 pruebas de lipsync.
SIN PROBAR EN GPU: LatentSync (no se pudo ejecutar aqui) y todo lo que carga modelos.
AVISO: la voz base de Chatterbox es una sola; los 10 avatares sonaran igual hasta tener otra fuente de voces.
Pendiente: unir los orquestadores de los modulos 9 y 14 con orquestador.py.
