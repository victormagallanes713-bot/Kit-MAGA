# Paquete v4 - sesion 2 (movimiento corporal + caras de medio cuerpo)

Problema detectado en la sesion 1: LatentSync solo mueve la boca; con una foto fija queda "estatua que habla".
Esta sesion prueba InfiniteTalk (Apache 2.0): cabeza, cuerpo y expresiones guiados por el audio.

Archivos
- instalar_infinitetalk.sh : plan (espacio y tamanos, no descarga) | instalar (entorno Python 3.10) | pesos (descarga)
- run_infinitetalk.sh      : foto + audio -> video con movimiento (fp8, 24 GB)
- sesion2_gpu.py           : caras de medio cuerpo con luz suave (4 candidatas en av01-av03) + prueba de movimiento
- lote2_gpu.sh             : lanza la sesion 2 en tmux
- lote_gpu.sh              : corregido (no reinstala Chatterbox por falta de memoria; sube solo diffusers para FLUX)

No verificado todavia: velocidad real en la 4090, que el audio en espanol funcione bien (el codificador es chino),
y que flash-attn use la version ya compilada. La sesion registra cuanto tarda cada clip.
