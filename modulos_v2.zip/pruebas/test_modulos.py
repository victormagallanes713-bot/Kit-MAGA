import os, sys, types, tempfile, json, sqlite3, time, hmac, hashlib, importlib
sys.path.insert(0, os.getenv("MODULOS_DIR", "/home/claude/modulos_corregidos"))
tmp = tempfile.mkdtemp()
os.environ.update({
    "VOZ_HMAC_SECRET": "x" * 40, "VOZ_DB": f"{tmp}/voz.db", "CONTRATO_DB": f"{tmp}/c.db",
    "REPARTO_DB": f"{tmp}/r.db", "M7_DB": f"{tmp}/m7.db", "BASE_DIR": tmp,
    "PAYMENT_WEBHOOK_SECRET": "w" * 40, "GATEWAY_API_KEY": "g" * 40,
    "CONTRATO_PATH": f"{tmp}/no_existe.md", "MODELS_REPO": tmp})
ok = fail = 0
def check(nombre, cond):
    global ok, fail
    if cond: ok += 1; print("OK   ", nombre)
    else: fail += 1; print("FALLA", nombre)
def lanza(f, *a, **k):
    try: f(*a, **k); return None
    except Exception as e: return e

# ---- comun_seguridad
import comun_seguridad as seg
check("hash_documento estable y largo", seg.hash_documento("001-1234567-8") == seg.hash_documento("0011234567 8") and len(seg.hash_documento("a")) == 64)
os.environ["VOZ_HMAC_SECRET"] = "cambiar-en-produccion"
check("secreto de ejemplo rechazado", isinstance(lanza(seg.secreto), RuntimeError))
os.environ["VOZ_HMAC_SECRET"] = ""
check("secreto vacio rechazado", isinstance(lanza(seg.hash_documento, "x"), RuntimeError))
os.environ["VOZ_HMAC_SECRET"] = "x" * 40

# ---- M20
import pp_modulo_20_consentimiento as M20
wav_a = f"{tmp}/a.wav"; wav_b = f"{tmp}/b.wav"; wav_c = f"{tmp}/c.wav"
for w in (wav_a, wav_b, wav_c): open(w, "wb").write(b"x")
check("M20 sin modelo falla en voz alta", "campplus" in str(lanza(M20.registrar_voz, "Ana", "123", wav_a, True, True)))
vec = {wav_a: [1, 0, 0], wav_b: [0.99, 0.14, 0], wav_c: [0, 1, 0]}
M20._embedding = lambda w: vec[str(w)]
r = M20.registrar_voz("Ana", "123", wav_a, True, True)
check("M20 registra", r["estado"] == "ACTIVO")
fp = r["fingerprint"]
con = sqlite3.connect(os.environ["VOZ_DB"]); fila = con.execute("select doc_hash from voces").fetchone()[0]; con.close()
check("M20 no guarda documento en claro", "123" != fila and len(fila) == 64)
check("M20 misma persona dos veces rechazada", M20.registrar_voz("Ana", "123", wav_a, True, True)["estado"] == "RECHAZADO")
check("M20 voz muy similar rechazada", M20.registrar_voz("Luis", "456", wav_b, True, True)["estado"] == "RECHAZADO")
check("M20 voz distinta aceptada", M20.registrar_voz("Eva", "789", wav_c, True, True)["estado"] == "ACTIVO")
check("M20 sin consentimiento rechazado", M20.registrar_voz("Zoe", "1", wav_c, False, True)["estado"] == "RECHAZADO")
check("M20 voz_activa antes de revocar", M20.voz_activa(fp))
check("M20 revoca", M20.revocar_voz(fp)["estado"] == "REVOCADA" and not M20.voz_activa(fp))
check("M20 tras revocar ya no bloquea voz similar", M20.verificar_voz(wav_b)["estado"] == "ACEPTADO")
check("M20 borra", M20.borrar_voz(fp)["estado"] == "BORRADA")
con = sqlite3.connect(os.environ["VOZ_DB"]); n = con.execute("select nombre,embedding,doc_hash from voces where fingerprint=?", (fp,)).fetchone(); con.close()
check("M20 borrado deja sin datos personales", n == ("[borrado]", None, ""))
check("M20 estado informa umbral no calibrado", M20.estado()["umbral_calibrado"] is False)

# ---- M21
import pp_modulo_21_contrato as M21
r = M21.firmar_contrato("Ana", "001-1", "locutor", "a@x.com", "1.1.1.1")
check("M21 firma sin exigir clonacion", r["estado"] == "ACTIVO" and "NO esta autorizada" in r["nota"])
check("M21 rol invalido rechazado", M21.firmar_contrato("A", "1", "xx")["estado"] == "RECHAZADO")
check("M21 contrato embebido sin clonacion obligatoria", "NO implica autorizar" in M21.CONTRATO_TEXTO and M21.avisos_contrato() == ["El texto esta marcado como BORRADOR."])
check("M21 firmante activo por documento", M21.firmante_activo("0011") is not None and M21.firmante_activo("999") is None)
asset = f"{tmp}/asset.mp4"; open(asset, "wb").write(b"v")
check("M21 depositar propio", M21.depositar("001-1", asset)["estado"] == "ACEPTADO")
check("M21 depositar sin firma rechazado", M21.depositar("777", asset)["estado"] == "RECHAZADO")
M20.registrar_voz("Eva2", "55", wav_a, True, True)
check("M21 tercero con voz de titular rechazado", M21.depositar("001-1", asset, True, "voz", wav_b)["estado"] == "RECHAZADO")
check("M21 retiro", M21.retirar(1)["estado"] == "RETIRADO")
con = sqlite3.connect(os.environ["CONTRATO_DB"]); h = con.execute("select doc_hash from firmantes").fetchone()[0]; con.close()
check("M21 doc_hash completo", len(h) == 64)

# ---- M22
import pp_modulo_22_huella_reparto as M22
bad = []
for c in list(range(0, 3000)) + [99999, 123456789]:
    r = M22.calcular_reparto(c)
    if r["titular_neto_c"] + r["empresa_total_c"] != c: bad.append(c)
check("M22 reparto suma exacta en 3000+ montos", not bad)
r = M22.calcular_reparto(100000)
check("M22 1000.00 -> titular bruto 550, comision 82.50, neto 467.50, empresa 532.50",
      (r["titular_bruto_c"], r["comision_tecnologica_c"], r["titular_neto_c"], r["empresa_total_c"]) == (55000, 8250, 46750, 53250))
check("M22 a_centavos", M22.a_centavos("12.345") == 1235 and M22.a_centavos(0.1) == 10 and isinstance(lanza(M22.a_centavos, "-1"), ValueError))
check("M22 c2pa sin evidencia rechazado", isinstance(lanza(M22.registrar_produccion, "R1", "Ana", asset, c2pa_aplicado=True), ValueError))
check("M22 disclosure sin evidencia rechazado", isinstance(lanza(M22.registrar_produccion, "R1", "Ana", asset, disclosure_ia_aplicado=True), ValueError))
p = M22.registrar_produccion("R1", "Ana", asset)
check("M22 produccion guarda banderas en 0 y firma", p["c2pa_aplicado"] is False and len(p["firma"]) == 64)
con = sqlite3.connect(f"{tmp}/r.db"); fila = con.execute("select c2pa_aplicado,disclosure_ia_aplicado,firma from producciones").fetchone(); con.close()
check("M22 firma almacenada", fila[0] == 0 and fila[1] == 0 and len(fila[2]) == 64)
h = p["huella"]
check("M22 pago sin base M7 rechazado", M22.registrar_pago(h, "EV1")["estado"] == "RECHAZADO")
m7 = sqlite3.connect(f"{tmp}/m7.db")
m7.execute("create table payment_events_v2(event_id text primary key,status text,amount_cents integer,currency text)")
m7.executemany("insert into payment_events_v2 values(?,?,?,?)", [("EV1", "PROCESSED", 100000, "USD"), ("EV2", "RECEIVED", 5000, "USD"), ("EV3", "FAILED", 5000, "USD")])
m7.commit(); m7.close()
r = M22.registrar_pago(h, "EV1")
check("M22 pago confirmado se reparte", r["estado"] == "OK" and r["titular_neto"] == "467.50" and r["empresa_total"] == "532.50")
check("M22 mismo cobro no se reparte dos veces", M22.registrar_pago(h, "EV1")["estado"] == "RECHAZADO")
check("M22 cobro RECEIVED rechazado", M22.registrar_pago(h, "EV2")["estado"] == "RECHAZADO")
check("M22 cobro FAILED rechazado", M22.registrar_pago(h, "EV3")["estado"] == "RECHAZADO")
check("M22 huella inexistente", M22.registrar_pago("HV-x", "EV1")["estado"] == "ERROR")
check("M22 adquisicion con pago inicial exige cobro", M22.registrar_adquisicion("1000", "Cli", h, "300")["estado"] == "RECHAZADO")
check("M22 adquisicion sin pago inicial 45%", M22.registrar_adquisicion("1000", "Cli", h)["total_empresa"] == "450.00")
check("M22 produccion con voz inexistente rechazada", isinstance(lanza(M22.registrar_produccion, "R2", "Ana", asset, voz_fingerprint="nope"), ValueError))
vivo = M20.registrar_voz("Nuevo", "9999", wav_c.replace("c.wav", "c.wav"), True, True)
# wav_c ya registrada por Eva -> rechazado; usar un wav nuevo
wav_d = f"{tmp}/d.wav"; open(wav_d, "wb").write(b"x"); vec[wav_d] = [0, 0, 1]
vivo = M20.registrar_voz("Nuevo", "9999", wav_d, True, True)
check("M22 produccion con voz activa aceptada", "huella" in M22.registrar_produccion("R3", "Nuevo", asset, voz_fingerprint=vivo["fingerprint"]))

# ---- M11 y M7 con stubs (no hay fastapi/sqlalchemy en este entorno)
def stub(nombre, **attrs):
    m = types.ModuleType(nombre); m.__dict__.update(attrs); sys.modules[nombre] = m; return m
class FakeApp:
    def __init__(s, **k): pass
    def get(s, *a, **k): return lambda f: f
    def post(s, *a, **k): return lambda f: f
    def on_event(s, *a, **k): return lambda f: f
    def api_route(s, *a, **k): return lambda f: f
class HTTPExc(Exception):
    def __init__(s, code, detail=""): s.code = code
stub("fastapi", FastAPI=FakeApp, Header=lambda **k: None, HTTPException=HTTPExc, Request=object, BackgroundTasks=object)
stub("fastapi.concurrency", run_in_threadpool=None)
stub("fastapi.responses", Response=object)
G = importlib.import_module("pp_modulo_11_gateway")
check("M11 clave correcta", G._clave_ok("g" * 40) and not G._clave_ok("x") and not G._clave_ok(None) and G._clave_ok("g" * 40 + "") )
check("M11 clave no ASCII no revienta", G._clave_ok("ñandú") is False)
os.environ["GATEWAY_API_KEY"] = "corta"
check("M11 clave corta impide arrancar", isinstance(lanza(G._api_key), RuntimeError))
os.environ["GATEWAY_API_KEY"] = "g" * 40
check("M11 rutas: .. rechazado", not G._ruta_segura("activos", "../etc/passwd") and not G._ruta_segura("activos", "a/../b"))
check("M11 ollama solo rutas de uso", G._ruta_segura("ollama", "api/generate") and not G._ruta_segura("ollama", "api/pull") and not G._ruta_segura("ollama", "api/delete"))
G.RATE_PER_MIN = 3
check("M11 limite de peticiones", [G._limite_ok("k") for _ in range(4)] == [True, True, True, False])
G.AUDIT_FILE = type(G.AUDIT_FILE)(f"{tmp}/gw/audit.jsonl"); G.AUDIT_FILE.parent.mkdir(parents=True)
G._auditar({"a": 1}); check("M11 auditoria a disco", G.AUDIT_FILE.read_text().strip() == '{"a": 1}')
check("M11 webhook sin clave solo en modulo7/webhook/", any("modulo7" == s and "webhook/interno".startswith(p) for s, p in G.RUTAS_SIN_CLAVE))

class Col:
    def __init__(s, *a, **k): pass
stub("sqlalchemy", Column=Col, String=1, DateTime=1, Integer=1, JSON=1, create_engine=lambda *a, **k: None)
stub("sqlalchemy.orm", sessionmaker=lambda **k: None, declarative_base=lambda: object)
stub("sqlalchemy.exc", IntegrityError=Exception)
stub("init_db", FinancialLedger=object)
stub("pp_modulo_4", liberar_si_pagado=None); stub("pp_modulo_5", order_credit_tokens_after_fiat_paid=None)
stub("pp_modulo_6", mlm_record_event=None, mlm_payout=None)
P = importlib.import_module("pp_modulo_7")
cuerpo = b'{"event_id":"E1","status":"paid","amount":"10.00"}'
ts = str(int(time.time()))
def firmar(body, t): return hmac.new(b"w" * 40, t.encode() + b"." + body, hashlib.sha256).hexdigest()
check("M7 firma valida", P.firma_valida(cuerpo, ts, firmar(cuerpo, ts)))
check("M7 firma incorrecta", not P.firma_valida(cuerpo, ts, "0" * 64))
check("M7 cuerpo alterado", not P.firma_valida(cuerpo + b" ", ts, firmar(cuerpo, ts)))
viejo = str(int(time.time()) - 1000)
check("M7 firma vencida (repeticion)", not P.firma_valida(cuerpo, viejo, firmar(cuerpo, viejo)))
check("M7 sin cabeceras", not P.firma_valida(cuerpo, None, None))
check("M7 a_centavos", P.a_centavos("19.99") == 1999 and isinstance(lanza(P.a_centavos, 0), ValueError) and isinstance(lanza(P.a_centavos, "x"), Exception))
check("M7 maximo 2 niveles aunque MLM_PCTS traiga 3", len(P.MLM_PCTS) <= 2 and P.MLM_MAX_NIVELES == 2)
check("M7 proveedores por defecto solo 'interno'", P.PROVEEDORES == {"interno"})
os.environ["PAYMENT_WEBHOOK_SECRET"] = "corto"
check("M7 secreto corto impide arrancar", isinstance(lanza(P._secreto), RuntimeError))
print(f"\n{ok} OK, {fail} fallas"); sys.exit(1 if fail else 0)
