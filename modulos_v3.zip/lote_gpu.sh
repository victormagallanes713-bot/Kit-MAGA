#!/usr/bin/env bash
# Sesion 1 en lotes. Dos modos:
#   bash lote_gpu.sh preparar            -> SIN GPU (pod CPU): instala paquetes y LatentSync, comprueba modelos
#   bash lote_gpu.sh ejecutar [--apagar] -> CON GPU: corre sesion1_gpu.py en tmux; --apagar detiene el pod si todo salio OK
set -uo pipefail
BASE="${BASE:-/workspace/projects/sistema_contenido_viral}"
VENV="${VENV_DIR:-/workspace/venv_ia}"
MODO="${1:-}"; shift || true
mkdir -p "$BASE/logs"
[ -f "$VENV/bin/activate" ] && source "$VENV/bin/activate"
cd "$BASE" || exit 1

ok(){ echo "  [OK]    $*"; }; no(){ echo "  [FALLO] $*"; FALLOS=$((FALLOS+1)); }
FALLOS=0

comprobar_modelos() {
  echo "== modelos =="
  [ -f /workspace/models_repository/flux/model_index.json ] && ok "FLUX" || no "falta FLUX en models_repository/flux"
  [ -d /workspace/models_repository/chatterbox ] && ok "Chatterbox" || no "falta models_repository/chatterbox"
  [ -f /workspace/models_repository/latentsync-1.5/latentsync_unet.pt ] && ok "LatentSync pesos" || no "faltan pesos LatentSync"
  [ -f /workspace/models_repository/faster-whisper-large-v3/model.bin ] && ok "faster-whisper" || no "falta faster-whisper model.bin"
  command -v ffmpeg >/dev/null && ok ffmpeg || no "falta ffmpeg"
}

if [ "$MODO" = "preparar" ]; then
  echo "== paquetes (venv_ia) =="
  for par in "diffusers:diffusers" "transformers:transformers" "accelerate:accelerate" "sentencepiece:sentencepiece" \
             "faster_whisper:faster-whisper" "chatterbox:chatterbox-tts"; do
    mod="${par%%:*}"; pk="${par##*:}"
    if python3 -c "import $mod" 2>/dev/null; then ok "$pk"; else
      echo "  instalando $pk ..."; pip install -q "$pk" && ok "$pk instalado" || no "no se pudo instalar $pk"; fi
  done
  echo "== LatentSync =="
  if [ -x "$BASE/instalar_latentsync.sh" ] || [ -f "$BASE/instalar_latentsync.sh" ]; then
    bash "$BASE/instalar_latentsync.sh" && ok "LatentSync instalado" || no "LatentSync no se pudo instalar"
  else no "falta instalar_latentsync.sh"; fi
  comprobar_modelos
  echo; [ "$FALLOS" = 0 ] && echo "TODO LISTO para encender la GPU." || echo "$FALLOS problema(s): copia lo de arriba y enviamelo."
  exit "$FALLOS"
fi

if [ "$MODO" = "ejecutar" ]; then
  command -v nvidia-smi >/dev/null && nvidia-smi -L >/dev/null 2>&1 || { echo "No hay GPU en este pod. Enciende el pod con GPU y repite."; exit 1; }
  python3 -c "import torch,sys;sys.exit(0 if torch.cuda.is_available() else 1)" || { echo "PyTorch no ve la GPU."; exit 1; }
  APAGAR=0; [ "${1:-}" = "--apagar" ] && APAGAR=1
  if [ -z "${TMUX:-}" ] && [ -z "${LOTE_EN_TMUX:-}" ]; then
    command -v tmux >/dev/null || { echo "falta tmux (apt-get install -y tmux)"; exit 1; }
    tmux kill-session -t sesion1 2>/dev/null
    tmux new -d -s sesion1 "LOTE_EN_TMUX=1 bash '$0' ejecutar $([ $APAGAR = 1 ] && echo --apagar)"
    echo "Lanzado en tmux (sigue aunque cierres el navegador). Ver avance:  tmux attach -t sesion1   (salir: Ctrl+B y luego D)"
    exit 0
  fi
  LOG="$BASE/logs/sesion1_$(date +%Y%m%d_%H%M).log"
  echo "Registro: $LOG"
  python3 sesion1_gpu.py 2>&1 | tee "$LOG"; RC=${PIPESTATUS[0]}
  if [ "$RC" = 0 ] && [ "$APAGAR" = 1 ]; then
    echo "Todo OK: deteniendo el pod (Stop, no Terminate)."
    runpodctl stop pod "${RUNPOD_POD_ID:?falta RUNPOD_POD_ID}" || echo "No pude detenerlo: hazlo desde la pagina My Pods."
  else
    echo "Terminado con codigo $RC. El pod SIGUE ENCENDIDO (cobrando): revisa y detenlo desde My Pods si ya no lo necesitas."
  fi
  read -r -p "Enter para cerrar" _ 2>/dev/null || true
  exit "$RC"
fi
echo "Uso: bash lote_gpu.sh preparar | bash lote_gpu.sh ejecutar [--apagar]"; exit 2
