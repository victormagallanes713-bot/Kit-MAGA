"""
Utilidades de seguridad compartidas por los modulos 7, 11, 20, 21 y 22.

Principios:
  - Un secreto por defecto es un fallo, no una comodidad: si falta, se detiene.
  - Los documentos de identidad nunca se guardan en claro ni con hash simple.
  - Los servicios escuchan solo en 127.0.0.1; la unica entrada publica es el gateway.
"""
import hashlib
import hmac
import os

SECRETOS_PROHIBIDOS = {"", "cambiar-en-produccion", "changeme", "secret", "password"}
LARGO_MINIMO = 16


def secreto(nombre="VOZ_HMAC_SECRET"):
    """Devuelve el secreto del entorno o detiene el servicio con un error claro."""
    v = os.getenv(nombre, "").strip()
    if v.lower() in SECRETOS_PROHIBIDOS or len(v) < LARGO_MINIMO:
        raise RuntimeError(
            f"Falta {nombre} o es debil (minimo {LARGO_MINIMO} caracteres y distinto del "
            f"valor de ejemplo). Generalo con: python3 -c \"import secrets;print(secrets.token_hex(32))\" "
            f"y guardalo en el archivo .env, nunca en el chat ni en GitHub.")
    return v


def hash_documento(doc, nombre_secreto="VOZ_HMAC_SECRET"):
    """HMAC-SHA256 completo del documento: no se puede revertir ni cotejar sin el secreto."""
    base = (doc or "").strip().upper().replace(" ", "").replace("-", "")
    return hmac.new(secreto(nombre_secreto).encode(), ("doc|" + base).encode(),
                    hashlib.sha256).hexdigest()


def firma(texto, nombre_secreto="VOZ_HMAC_SECRET"):
    return hmac.new(secreto(nombre_secreto).encode(), texto.encode(),
                    hashlib.sha256).hexdigest()


def iguales(a, b):
    """Comparacion en tiempo constante, segura con texto no ASCII."""
    return hmac.compare_digest(str(a).encode("utf-8"), str(b).encode("utf-8"))


HOST_API = "127.0.0.1"   # no se ofrece alternativa: la salida publica es el gateway
