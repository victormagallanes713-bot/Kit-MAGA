"""
Módulo 10 — API de Producción.

Expone el pipeline multimedia como servicio (puerto 8030) y delega en los scripts
REALES del proyecto (_05_scripts/). No inventa comandos: detecta qué existe y
ejecuta lo disponible; si un motor (Whisper/XTTS/lipsync) no está instalado,
devuelve un estado claro en lugar de fallar.

Endpoints:
  GET  /pipeline/estado         -> qué motores están disponibles
  POST /pipeline/run            -> lanza una producción (run_id + manifiesto)
  GET  /pipeline/run/{run_id}   -> estado del run
"""
import os, json, uuid, subprocess, shutil
from datetime import datetime, timezone
from pathlib import Path

try:
    from manifest import firmar, validar
except Exception:
    def firmar(service, payload, run_id=None, ttl=60):
        return {"service": service, "payload": payload}
    def validar(m, p):
        return True, "sin-manifiesto"

BASE_DIR = Path(os.getenv("PROD_BASE", "/workspace/projects/sistema_contenido_viral"))
SCRIPTS = BASE_DIR / "_05_scripts"
RENDERS = BASE_DIR / "07_master_render"
RUNS_DB = BASE_DIR / "database" / "production_runs.json"

# catálogo de motores: nombre -> cómo detectarlo
MOTORES = {
    "faster-whisper": {"cmd": None, "script": None, "modulo": "faster_whisper", "rol": "transcripcion"},
    "chatterbox": {"cmd": None, "script": None, "modulo": "chatterbox", "rol": "tts"},
    "latentsync": {"cmd": None, "script": "../run_latentsync.sh", "rol": "lipsync"},
    "ffmpeg": {"cmd": "ffmpeg", "script": None, "rol": "mux"},
    "ollama": {"cmd": "ollama", "script": None, "rol": "llm"},
}


def _now():
    return datetime.now(timezone.utc).isoformat()


def _load_runs():
    if RUNS_DB.exists():
        try:
            return json.loads(RUNS_DB.read_text())
        except Exception:
            return {}
    return {}


def _save_runs(d):
    RUNS_DB.parent.mkdir(parents=True, exist_ok=True)
    RUNS_DB.write_text(json.dumps(d, indent=2, default=str))


def estado_motores():
    est = {}
    for nombre, cfg in MOTORES.items():
        bin_ok = bool(cfg["cmd"]) and shutil.which(cfg["cmd"]) is not None
        sc = cfg["script"] or ""
        script_ok = bool(sc) and ((BASE_DIR / sc[3:]) if sc.startswith("../") else (SCRIPTS / sc)).exists()
        mod_ok = False
        if cfg.get("modulo"):
            import importlib.util
            mod_ok = importlib.util.find_spec(cfg["modulo"]) is not None
        est[nombre] = {
            "rol": cfg["rol"], "binario_disponible": bin_ok,
            "script_disponible": script_ok, "paquete_disponible": mod_ok,
            "listo": bin_ok or script_ok or mod_ok,
        }
    est["scripts_en_proyecto"] = sorted(
        p.name for p in SCRIPTS.glob("*.py")) if SCRIPTS.exists() else []
    return est


def lanzar_produccion(area, entrada, objetivo="", idiomas=None, avatar_ids=None,
                      actor="Orchestrator"):
    """Lanza una producción. Devuelve run_id y manifiesto firmado."""
    run_id = f"RUN-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:6]}"
    payload = {
        "area": area, "entrada": entrada, "objetivo": objetivo,
        "idiomas": idiomas or ["es"], "avatar_ids": avatar_ids or [],
    }
    manifiesto = firmar("mod10_produccion", payload, run_id=run_id)
    runs = _load_runs()
    runs[run_id] = {
        "run_id": run_id, "estado": "ENCOLADO", "payload": payload,
        "manifiesto": manifiesto, "actor": actor, "creado": _now(),
        "pasos": [], "motores": estado_motores(),
    }
    _save_runs(runs)
    return runs[run_id]


def ejecutar_paso(run_id, motor):
    """Ejecuta un paso REAL del pipeline usando los motores de pp_modulo_17."""
    runs = _load_runs()
    if run_id not in runs:
        raise KeyError("run no existe")
    r = runs[run_id]
    p = r["payload"]
    try:
        import pp_modulo_17_motores as M17
    except Exception as e:
        paso = {"motor": motor, "ts": _now(), "estado": "NO_DISPONIBLE", "detalle": str(e)}
        r["pasos"].append(paso); r["estado"] = "EN_PROCESO"; runs[run_id] = r
        _save_runs(runs); return paso
    try:
        if motor in ("transcripcion", "whisper"):
            res = M17.transcribir(p.get("entrada"), idioma=p.get("idioma"))
            if res.get("estado") != "OK":
                paso = {"motor": motor, "ts": _now(), "estado": res.get("estado"), "detalle": res.get("detalle", "")}
            else:
                paso = {"motor": motor, "ts": _now(), "estado": "OK",
                        "duracion_s": res["duracion_s"], "chars": len(res["texto"]),
                        "texto": res["texto"][:3000]}
        elif motor in ("tts", "voz", "clon"):
            res = M17.clonar_voz(p.get("texto", ""), p.get("ref_audio"),
                                 p.get("salida_audio", "/workspace/tmp/" + run_id + ".wav"),
                                 idioma=(p.get("idiomas") or ["es"])[0],
                                 consentimiento_ref=p.get("consentimiento_ref"),
                                 voz_fingerprint=p.get("voz_fingerprint"))
            paso = {"motor": motor, "ts": _now(), "estado": res.get("estado"),
                    "salida": res.get("salida"), "detalle": res.get("detalle", "")}
        elif motor in ("mux", "render"):
            res = M17.mux_video(p.get("visual"), p.get("audio"),
                                p.get("salida_video", "/workspace/tmp/" + run_id + ".mp4"))
            paso = {"motor": motor, "ts": _now(), "estado": res.get("estado"),
                    "salida": res.get("salida"), "detalle": res.get("stderr_tail", "")}
        elif motor in ("flux", "personaje"):
            import pp_modulo_18_video as M18
            res = M18.generar_imagen_flux(p.get("prompt", "personaje"),
                                          p.get("salida_img", "/workspace/tmp/" + run_id + ".jpg"),
                                          seed=p.get("seed"))
            paso = {"motor": motor, "ts": _now(), "estado": res.get("estado"),
                    "salida": res.get("salida"), "detalle": res.get("detalle", "")}
        elif motor in ("lipsync", "latentsync"):
            import pp_modulo_18_video as M18
            res = M18.lipsync_latentsync(p.get("face"), p.get("audio"),
                                         p.get("salida_video", "/workspace/tmp/" + run_id + ".mp4"),
                                         consentimiento_ref=p.get("consentimiento_ref"),
                                         es_persona_real=bool(p.get("es_persona_real", False)))
            paso = {"motor": motor, "ts": _now(), "estado": res.get("estado"),
                    "salida": res.get("salida"), "detalle": res.get("stderr_tail", "")}
        elif motor in ("escena", "video"):
            import pp_modulo_18_video as M18
            res = M18.armar_escena(p.get("prompt_personaje", "personaje"), p.get("audio"),
                                   p.get("salida_video", "/workspace/tmp/" + run_id + ".mp4"),
                                   seed=p.get("seed"), consentimiento_ref=p.get("consentimiento_ref"))
            paso = {"motor": motor, "ts": _now(), "estado": res.get("estado"),
                    "salida": res.get("salida")}
        else:
            est = estado_motores().get(motor, {})
            paso = {"motor": motor, "ts": _now(),
                    "estado": "LISTO_PARA_CONECTAR" if est.get("listo") else "NO_DISPONIBLE"}
    except Exception as e:
        paso = {"motor": motor, "ts": _now(), "estado": "ERROR", "detalle": str(e)}
    r["pasos"].append(paso)
    r["estado"] = "EN_PROCESO"
    runs[run_id] = r
    _save_runs(runs)
    return paso


def estado_run(run_id):
    return _load_runs().get(run_id)


if __name__ == "__main__":
    import uvicorn
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel

    app = FastAPI(title="API de Producción (pp_modulo_10)")

    class Prod(BaseModel):
        area: str
        entrada: str
        objetivo: str = ""
        idiomas: list[str] = ["es"]
        avatar_ids: list[str] = []

    @app.get("/pipeline/estado")
    def api_estado():
        return estado_motores()

    @app.post("/pipeline/run")
    def api_run(b: Prod):
        return lanzar_produccion(b.area, b.entrada, b.objetivo, b.idiomas, b.avatar_ids)

    @app.get("/pipeline/run/{run_id}")
    def api_run_estado(run_id: str):
        r = estado_run(run_id)
        if not r:
            raise HTTPException(404, "run no existe")
        return r

    @app.post("/pipeline/run/{run_id}/paso/{motor}")
    def api_paso(run_id: str, motor: str):
        try:
            return ejecutar_paso(run_id, motor)
        except KeyError as e:
            raise HTTPException(404, str(e))

    uvicorn.run(app, host="127.0.0.1", port=8030)
